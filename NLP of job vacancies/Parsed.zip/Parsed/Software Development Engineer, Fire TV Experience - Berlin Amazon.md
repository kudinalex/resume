## 
              About the job

**Description** Join our Berlin team! We're building an ecosystem of FireTV device components that helps the users setup, interact and control FireTV devices. Fire TV is how millions of people watch, share, and enjoy TV every day. We are looking for talented engineers to help Fire TV continue being the global leader in entertainment with the best experience for customers and partners and the broadest selection of content and services. You will be implementing core pieces of a product used every day, by people you probably know.  
  
This role focuses on device-side work spanning Android, Java and, to a lesser extent, Kotlin, React Native, Rust and AWS.  
  
This is a high visibility team which owns a key piece of Fire TV technology, and we have almost complete cross-functional ownership of our components and roadmap based in Berlin (we still rely on Seattle for UX support, and continue to have close interactions with partner teams).  
  
Key job responsibilities  
  
Contribute to the design and implementation of features on Fire TV devices spanning all types (TVs, Sticks, Cubes, other), focusing on constantly improving the daily experience of millions of customers.  
  
A day in the life  
  
Participate in Agile development with complete team ownership of the scope and domain.  
  
Design, implement and deliver features on the Fire TV Android codebase.  
  
**About The Team** We are the Fire TV organization's Berlin branch. Our 40+ member team owns both client and service implementations for a number of domain areas. We are managed and supported by a Berlin-based leadership team, and are responsible for the roadmap we deliver to Fire TV for worldwide-spanning features.  
  
We are open to hiring candidates to work out of one of the following locations:  
  
Berlin, BE, DEU  
  
**Basic Qualifications**      
- Experience in professional, non-internship software development
- 2+ years of non-internship design or architecture (design patterns, reliability and scaling) of new and existing systems experience
- Experience programming with at least one modern language such as Java, C++, or C# including object-oriented design

**Preferred Qualifications**
- Bachelor's degree in computer science or equivalent
- Experience of full software development life cycle, including coding standards, code reviews, source control management, build processes, testing, and operations experience

Amazon is an equal opportunities employer. We believe passionately that employing a diverse workforce is central to our success. We make recruiting decisions based on your experience and skills. We value your passion to discover, invent, simplify and build. Protecting your privacy and the security of your data is a longstanding top priority for Amazon. Please consult our Privacy Notice (https://www.amazon.jobs/en/privacy\_page) to know more about how we collect, use and transfer the personal data of our candidates.  
  
m/w/d  

**Company** - Amazon Development Center Germany GmbH  
  
Job ID: A2521563