## 
              About the job

**What To Expect** In the position of a Software Engineer you will oversee a team of developers and ensure that each is delivering the highest quality. You will focus on building the best software products for our logistics operations, intended for, but not limited to, the European market. By optimizing and extending our existing applications, you will leverage state-of-the-art technologies and contribute to a high-performing and scalable system. It is an exciting and demanding position that requires to multitask, prioritize and work in an extremely fast-moving, collaborative environment. Because you are working on urgent, immediate changes, you have excellent problem-solving skills, the ability to interpret data and identify improvements in the given context.  
  
**What You'll Do** - Collaborate with other cross-functional teams such as product managers, quality engineers and release engineers to own your solution from start to deployment
- Provide improvement recommendations that are based on best practices and industry standards, continuously monitor the new trends to inform current decisions
- Be the team's point of contact for technical decisions and remove obstacles. Handle multiple projects and tasks in parallel
- In addition to ongoing projects, you are responsible for tackling urgent problems that require immediate action
- Able to communicate and collaborate with domain experts from different disciplines. The ability to handle multiple projects and tasks in parallel
- Communicative and operational skills as well as the ability to work with many stakeholders. Able to communicate and collaborate with domain experts from different disciplines
- Investigate root cause of failures to drive continual improvement. And continually learn, set, teach, apply software best practices, tools and technologies
**What You'll Bring** - At least six years of experience in latest backend web stack: NET core, C#, and Angular or React
- Proven experience in being a tech lead for a minimum of two years. Excellent knowledge in RESTful web services and web applications
- Strong experience with stream- and event processing frameworks, i.e. Kafka, RabbitMQ, or ActiveMQ
- Excellent knowledge of SQL and NoSQL databases, i.e., MongoDB, MySQL, or MSSQL
- Must be proficient user in Jira, Confluence and Git. Have experience with building scalable- and distributed systems
- Experience with international logistics, carrier or shipping operations and systems is a plus
- Mastering the English language in both written and verbal form is required. Some degree of flexibility is desired as different teams work in different time zones
Tesla