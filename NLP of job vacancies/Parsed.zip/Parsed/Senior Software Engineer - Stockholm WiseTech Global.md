## 
              About the job

WiseTech is a technical company from the top down and we’re looking for Senior Software Engineer’s to join us.

As an Engineer lead organisation, we invest heavily in R&D and are constantly improving, updating and adding new features to our flagship product, CargoWise. The global supply chain is under stress, with shortages in materials abundant, increasing cross border complexities and uncertainties in transport. Working at WiseTech means solving these complex problems for the largest Logistics organisations on the planet. Senior Software Engineers are mentors, leaders, and experts in their craft.

We are a quality driven organisation, maintaining an incredibly low defect rate. Our core mantra “Slower today, faster forever” means we build a culture that allows our Engineers to focus on delivering high quality product, limiting technical debt. We are not a deadline driven environment, but are driven by writing clean, maintainable, and reusable code. This role will enable you to make a real-world impact by developing innovative solutions that solve persistent pain points of the logistics industry. Our developers work on top-spec hardware.

**What we’re looking for**

Whilst we’re looking for experienced C# Developers, we utilise multiple different technologies across our features and functions, and we encourage a diverse environment where people can bring their skills to the table and for Engineers work with new technologies. At WiseTech we know a talented engineer is more than the tools they use. We do not assess applications based on tech stack but on achievement. So, share a link to your Github or Stack Overflow, let us know why you are a Software Engineer.

**Benefits**

Our people are the foundations of our business, and we value the contribution and commitment they make. We have a range of benefits including generous leave, flexible working, development opportunities, employee assistance programs, remote working allowance, and more. We are offering a Hybrid model of work, with the option of working from our offices based centrally in Stockholm

**About WiseTech Global**

At WiseTech Global we build leading technology solutions that help the logistics industry move goods globally. Our customers include the world’s largest logistics companies like FedEx and DHL. Our innovations and global technology enables, improves and empowers the world’s supply chains. Having listed on the ASX in 2016, WiseTech Global is an AU$12 billion+ company that is serious about expansion and technical innovation. Through a combination of organic growth and targeted acquisitions, our global employee head count has increased rapidly, and we’re far from slowing down. Our mission is to change the world by creating breakthrough products that empower those that own, enable, and operate the supply chains of the world.

**Before you Apply**

From time to time, WiseTech Global may use an external service provider to assess applications on our behalf. Accordingly, by applying for this role and providing your personal information to WiseTech Global, you consent to WiseTech Global providing this information to our external service providers who are required to treat such information with strict confidentiality in line with privacy and data protection laws and regulations.