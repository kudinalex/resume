## 
              About the job

**Company Description** **Although you might see this job advert being based in London, we'll consider candidates who are also happy to work from our Birmingham and Belfast offices.** We're ASOS. We blend our flair for fashion with our love of cutting- edge technology, but more importantly were interested in how we can bring the best out of you.  
  
We exist to give people the confidence to be whoever they want to be, and that goes for our people too. At ASOS, you're free to be your true self without judgment, and channel your creativity into a platform used by millions.  
  
Through our Fashion with Integrity strategy  we are driving diversity, equity and inclusion across every aspect of ASOS and ensuring every ASOSer can be their authentic self at work.  We want our people to be whoever they want to be, because we believe people who bring their best selves to work, do their best work.  
  
**Job Description** At ASOS, we take real pride in our best-in-class microservices architecture, whilst sticking to the ASOS values of Authentic, Brave, Creative & Disciplined, and are looking for Software Engineers to support and deliver the on-going software which makes ASOS awesome!  
  
As a Software Engineer in one of our 30 engineering platforms operating at hyper-scale receiving thousands of requests per second, you'll be a hands-on engineer pushing best practice engineering processes and approaches, and driving the capabilities of the platform, ensuring continuous product improvement and ongoing development of engineers through coaching, mentoring and pairing.  
  
By applying to this role, you’re expressing interest in working for one of our teams; our Talent team will work with you to find your best fit in terms of experience, skill-set, location and setting you up for success.  
  
**What You’ll Be Doing**      
- Work as part of an enthusiastic and motivated agile development team that takes pride in delivering high-quality software into production
- Take a test first approach from business requirements through to code
- You will continually develop and improve our code and technology, whilst playing an active role in the conception of brand-new features for our millions of global customers
- Coaching and mentoring more Junior team members
- Keep our customers happy by writing high quality code to handle our hyper-scale demand
- Join our regular Tech Develops days to learn new things, take part in internal and external hackathons, share your knowledge and help to drive improvements in engineering
- Supporting our culture by championing Diversity, Equity & Inclusion strategies.

**Qualifications** **Who We’d Like to Meet**
- Extensive development experience with .NET Core or C#
- Cloud computing (Azure, AWS or GCP)
- Cloud databases (SQL, NoSQL)
- Infrastructure as code (Terraform, Pulumi, ARM, Bicep or similar)
- CI/CD tools (TeamCity, Octopus, Azure DevOps, Jenkins or similar)
- Performance/load testing
- Test-Driven Development best practices using TDD, BDD/ATDD
- Design patterns (architecture, system, security, networking)
- Cloud integration (Azure Service Bus, Azure Functions, Logic Apps)
- Docker, Kubernetes (preferably AKS)
- Experience of working within an integration domain

**Additional Information** **What’s in it for you?**
- Employee discount (hello ASOS discount!)
- ASOS Develops (personal development opportunities across the business)
- Employee sample sales
- Access to a huge range of LinkedIn learning materials
- 25 days paid annual leave + an extra celebration day for a special moment
- Discretionary performance related bonus scheme
- Private medical care scheme
- Flexible benefits allowance - which you can choose to take as extra cash, or use towards other benefits

**Our Commitments** We want our people to be whoever they want to be. That’s why we’re committed to creating a truly inclusive culture at ASOS, but how’re we doing it?  
  
We’re proud members of Inclusive Companies, are Disability Confident Committed and have signed the Business in the Community Race at Work Charter. We’ve also recently been placed 8th in the Inclusive Top 50 Companies Employer List too.  
  
We have several employee networks that operate as safe spaces, to help support and celebrate our people, find out more here.  
  
How can we support you to be your best self? Our Talent team will be happy to provide support e.g. if you need additional time to prepare for an assessment or you have requirements for any part of the interview/hiring process - just let us know by email or phone, whatever works best for you. It’s also our policy to interview all candidates with a disability who meet the minimum requirements for roles they have applied to.  
  
If you have any questions about the policies we have in place to support our employees (e.g. our parental leave approach), just let our Talent team know.