## 
              About the job

**Job Title** Full Stack Software Engineer  
  
**Role Overview** We began by taking hotel bookings online over 20 years ago and we've been shaping the travel industry ever since. Today, we're building a platform that connects all parts of the trip – from accommodation to transport, flights, tickets, tours and much more!  
  
From our hubs in Manchester, London, Amsterdam our Trips Business Unit helps people get where they want to go, anywhere in the world. Whether customers want the freedom of a car, the convenience of a flight, the ease of a taxi or the economy of public transport, we make it all possible.  
  
Our team is passionate about helping people travel. They see challenges as opportunities. And they’re always ready for change.  
  
The Trip Horizontal Product (THP) team mission is to provide travelers with the easiest multi-product travel planning and booking experience. While being part of the Trips Business Unit we are at the core of bridging the Booking of today into the Booking of tomorrow, and leading the evolution of Booking from a single product company to a multi-product offering company with an outstanding, personalised travel experience at the heart of its success.  
  
**Key Job Responsibilities And Duties** Our ideal candidate has an excellent eye for detail, pragmatic approach and an absolute commitment to making sure features are well implemented and bug free. We make our decisions based on experiments and testing, so you should be excited by taking a data-led approach to development. If you believe you’re also a passionate advocate for the user, and are looking to work in an agile, collaborative environment then we would like to hear from you!  

- Rapidly developing next-generation scalable, flexible, and high-performance systems.
- Solving issues with the systems, prioritizing based on customer impact.
- Advocating best development practices within the team.
- Be owner for teams’ microservices and services.
- Acting as an intermediary for problems, with both technical and non-technical audiences.
- Collaborating with adjacent teams and other partners to deliver on business objectives
- Contribute to Booking.com's growth through interviewing, on-boarding, or other recruitment efforts.
- Experience working on products that impact a large user base or in an entrepreneurial startup environment.
- Passionate learners who aren’t afraid of new tools and technologies to build a great end-to-end customer experience.

**Role Qualifications And Requirements** Understanding the full stack of web development is vitally important in this role. We need self-starters who are great at solving problems, who initiate discussions, are solution-oriented, customer focused and believe that any challenge can be scaled with the right attitude and tools.  
  
**We Are Looking For**
- A minimum of 3 years of experience in web development.
- Strong software development experience with Node.js and Java.
- Very good understanding of APIs design and Kafka queues.
- Experience in front-end development with Vanilla JavaScript, TypeScript, React.
- Experience with service oriented architecture.
- Demonstrable experience with multiple database systems (MySQL, Cassandra, etc.).
- Experience with defining and upholding SLOs/critical metrics.
- Proficiency with containerized applications.
- Experience with data-driven product development: analytics, A/B testing, etc.
- Excellent communication; written and spoken.l.

**Benefits & Perks: Global Impact, Personal Relevance: ** **Benefits**Booking.com’s total rewards philosophy is not only about compensation but also about benefits. Our rewards are aimed at making it easier for you to experience all that life has to offer — all the messy, beautiful, and joyful bits — on your terms. So you can focus on what really matters. We offer competitive compensation as well as thoughtful, valuable, and even fun benefits which include:  

- A great, brand new office in the heart of Amsterdam
- Free breakfast and lunch
- 25 days’ paid holiday plus bank holidays (rising to 28 days after 3 years of service)
- Health & well-being benefits such as mental health support, cycle to work scheme, access to health insurance, etc.
- Employer contribution pension
- Industry-leading parental leave and adoption leave
- Great discounts on accommodation, car rentals and other group benefits
- From day one of your employment with us, we offer 22 weeks’ fully paid leave for all new parents, regardless of gender or the way you become a parent
- We aim to empower you to do your best work, whether in the office or at home, as well as 20 days per year to work from abroad with our Work from Abroad benefit\*
- Carer’s leave. 10 days’ fully paid leave per year for colleagues who are caring for ill family members.
- Hybrid Working (NL): We believe in office attendance at least 40% of your time whilst empowering you with the flexibility to plan where to do your best work, as well as up to 20 days per year to Work from Abroad\* (subject to terms and conditions)

**#ThinkInclusion: Wellbeing & Inclusion at Booking.com:** Inclusion, Diversity, Belonging, Wellbeing and Volunteering (IDBWV) have been a core part of our company culture since day one. This ongoing journey starts with our very own employees, who represent over 140 nationalities and a wide range of ethnic and social backgrounds, genders and sexual orientations. Take it from our Chief People Officer, Paulo Pisano: “At Booking.com, the diversity of our people doesn’t just create a unique workplace, it also creates a better and more inclusive travel experience for everyone. Inclusion is at the heart of everything we do. It’s a place where you can make your mark and have a real impact in travel and tech.” We will ensure that individuals with disabilities are provided reasonable adjustments to participate in the job application or interview process, to perform essential job functions, and to receive other benefits and privileges of employment. Please contact us to discuss any requirements.  
  
Booking.com is proud to be an equal opportunity workplace and is an affirmative action employer. All qualified applicants will receive consideration for employment without regard to race, colour, religion, gender, gender identity or expression, sexual orientation, national origin, genetics, disability, age, or veteran status. We strive to move well beyond traditional equal opportunity and work to create an environment that allows everyone to thrive.  
  
**Career Development Opportunities** At Booking.com, we’re constantly growing and we want to provide resources to help grow your career.  

- Free access to online learning platforms
- Development and mentorship programs to support career growth
- Access to trainings and workshops
- Team development opportunities

**Application Process** Please submit your application via the ‘Apply Now’ button above, your details will be reviewed by one of our Recruiters.  
  
Your Recruiter will discuss the full interview process and they will ensure that you are fully prepared for each stage of the interview process.  
  
**Pre- Employment Screening** If your application is successful, your personal data may be used for a pre-employment screening check by a third party as permitted by applicable law. Depending on the vacancy and applicable law, a pre-employment screening may include employment history, education and other information (such as media information) that may be necessary for determining your qualifications and suitability for the position.