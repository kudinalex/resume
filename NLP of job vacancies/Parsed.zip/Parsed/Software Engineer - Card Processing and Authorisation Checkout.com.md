## 
              About the job

**Company Description** Checkout.com is one of the most exciting FinTechs in the world. Our mission is to enable businesses and their communities to thrive in the digital economy. We’re the strategic payments partner for some of the best known fast-moving brands globally such as Wise, Hut Group, Sony Electronics, Homebase, Henkel, Klarna and many others. Purpose-built with performance and scalability in mind, our flexible cloud-based payments platform helps global enterprises launch new products and create experiences customers love. And it's not just what we build that makes us different. It's how.  
  
We empower passionate problem-solvers to collaborate, innovate and do their best work. That’s why we’re on the Forbes Cloud 100 list and a Great Place to Work accredited company. And we’re just getting started. We’re building diverse and inclusive teams around the world — because that’s how we create even better experiences for our merchants and our partners. And we need your help Join us to build the digital economy of tomorrow.  
  
**Job Description** **The team** Part of the Core Network pillar, the Card Processing team is responsible for building the card scheme “rails” like VISA and Mastercard that are at the heart of what Checkout offers to its customers. The team owns some of the highest traffic and most business critical systems we have, and are on a mission to make them faster, more resilient, more cost effective, all while constantly keeping up with new features.  
  
**The role** Exposed to the entire software development lifecycle (SDLC), you'll work on the specification, design, coding, testing and deployment of various Payments solutions. The ideal candidate is passionate and spirited, lives and breathes Agile and truly believes in crafting clean, testable code.  
  
**How You’ll Make An Impact**      
- Collaborate with cross-functional teams, including product management, design, and QA
- Stay up-to-date and use the latest technologies from AWS, Github etc.
- Design and develop scalable C# applications using industry best practices
- Write clean, maintainable, extendable and testable code
- Define and design systems in a wider microservices' ecosystem
- Support the creation and maintenance of technical documentation
- Provide input and enforce into teams and wider organization continuous improvement around technology, standards, best practices, and processes

**Qualifications** **What we’re looking for**
- Strong experience in designing, testing, implementing and documenting APIs using C# programming language
- Enjoy learning new skills and using the best tools for the job
- Understanding SOLID principles and TDD practices
- Solid understanding of HTTP and RESTful design
- Proven track record of ability to translate requirements into scalable software systems design
- Experience with Continuous Integration and Deployment workflows
- Great communication skills and ability to interact effectively with versatile teams
- Knowledge of microservice architecture and design patterns
- Proven ability to lead development efforts is a plus
- Having an understanding of how the cloud works is a plus

**Additional Information** **Apply without meeting all requirements statement** If you don't meet all the requirements but think you might still be right for the role, please apply anyway. We're always keen to speak to people who connect with our mission and values.  
  
**We believe in equal opportunities** We work as one team. Wherever you come from. However you identify. And whichever payment method you use.  
  
Our clients come from all over the world — and so do we. Hiring hard-working people and giving them a community to thrive in is critical to our success.  
  
When you join our team, we’ll empower you to unlock your potential so you can do your best work. We’d love to hear how you think you could make a difference here with us.  
  
We want to set you up for success and make our process as accessible as possible. So let us know in your application, or tell your recruiter directly, if you need anything to make your experience or working environment more comfortable. We’ll be happy to support you.  
  
**Take a peek inside life at CKO via**
- Our careers page https://www.checkout.com/careers
- Our LinkedIn Life pages bit.ly/3OaoN1U
- Our Instagram https://www.instagram.com/checkout\_com/

**Apply Without Meeting All Requirements Statement** If you don't meet all the requirements but think you might still be right for the role, please apply anyway. We're always keen to speak to people who connect with our mission and values.  
  
**We believe in equal opportunities** We work as one team. Wherever you come from. However you identify. And whichever payment method you use.  
  
Our clients come from all over the world — and so do we. Hiring hard-working people and giving them a community to thrive in is critical to our success.  
  
When you join our team, we’ll empower you to unlock your potential so you can do your best work. We’d love to hear how you think you could make a difference here with us.  
  
We want to set you up for success and make our process as accessible as possible. So let us know in your application, or tell your recruiter directly, if you need anything to make your experience or working environment more comfortable. We’ll be happy to support you.  
  
**Take a peek inside life at Checkout.com via**
- Our Culture video https://youtu.be/BEwnpHuadSw
- Our careers page https://www.checkout.com/careers
- Our LinkedIn Life pages bit.ly/3OaoN1U
- Our Instagram https://www.instagram.com/checkout\_com/