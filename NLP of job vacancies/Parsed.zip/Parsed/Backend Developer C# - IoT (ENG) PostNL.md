## 
              About the job

Using IoT technology and AWS Serverless products to digitalise our end-to-end parcel supply chain. 300.000 rollcontainers are an integral part of getting parcels from A to B and you will help PostNL make them smart and share the data  
  
**Wat ga je doen?** When joining us in this role of Software Engineer you will join our IoT-team and become part of our Supply Chain Management and eCommerce operation; the fastest growing business of PostNL. Nowadays we deliver an average of 1.1 million parcels per day. Our ultimate goal is to digitalise our end-to-end parcel supply chain. As an example, using “Internet of Things” we track all our roll containers (about 300.000) on which we transport our parcels. For this we make use of Bluetooth beacons and it results in a real-time IoT landscape that continuously updates us with location and sensor information. The IoT platform is fully designed using AWS serverless components. In general serverless architecture is key in the development of all our components. Examples of technologies we use are AWS IoT Services, Amazon Location Services, AWS Kinesis Streams and AWS Lambda’s. For our software development stack we develop in C# (.NETcore) and TypeScript as much as possible. We believe in the power of Infrastructure as Code (IaC) to transform the way we build, deploy, and manage our infrastructure, and we do this by using AWS CDK with Typescript.  
  
What is your role?  
  
In this role as Software Engineer for IoT you will be part of a Scrum team. Together with your team mates you will be further designing and developing our IoT applications. For the coming years we some interesting challenges to improve our IoT landscape. For instance we have the challenge of how to manage the incoming generation of millions real-time messages per minute send by the 350.000 beaconed roll containers. You will also help us in rolling out new IoT applications to also give us real-time visibility on other operational areas within PostNL. The opportunities are endless and the impact will be huge! Besides your role in this Scrum team you also will be part of PostNL general engineering community, that drives engineering best practices and shares tech innovations through the whole company.  
  
**Wat breng jij mee?** You are obviously exited and passionate about working in an IoT driven environment using things like various AWS technologies, C# and TypeScript. In addition you would love to work in a close collaborative Scrum team with fellow tech fanatics and engage in areas like architecture, CI/CD and scalability and the exploration of new possible IoT features.  
  
Next to this you will have:  

- Experience as a Software engineer in C# (.Net Core) and AWS;
- Experience with developing Cloud enabled software in a cloud only environment;
- At least two years’ experience in another tech company or tech innovative environment.

**Wat bezorgen we jou?** In PostNL we find ourselves in a unique moment of time in which we see lots of greenfield situations. We are ambitious in our Supply Chain Management business, but we stand together as a team to make it happen. Together with your direct team members, IT-professionals with various specialties from other business and with our whole IT Community we transform PostNL into a true Tech company. Your personal development is essential for us and we will stimulate you to grow and facilitate you with the necessary growth opportunities.  
  
Next to this we will offer you:  

- A position in scale 11 or 12, depending on your level, with a gross monthly salary between Eur. 4.538,- and Eur. 7.054,-
- A workweek is between 32-37 hours with a healthy work-life balance. The team works maximum 1 or 2 days in the office (The Hague HS). You will get a NS Business card for your travel expenses"
- An environment in which you can work with, and learn more about the latest state of the art AWS technologies;
- Growing agile teams where you will have the freedom to take ownership in growing with and as a team. You and your fellow team members, shape the way you collaborate, continuously learn and grow with a shot of daily fun and challenging puzzles;
- Flexible working hours to determine an optimal work / private balance. We place great value on your vitality;

Interested?  
  
PostNL wants to be the preferred delivery company for everyone. So everyone is welcome with us and it doesn't matter where you were born, what you believe in or who you love. We care about your unique talent.  
  
For more information about the vacancy and the process, Lee Verschuren, the recruiter for this vacancy, is happy to speak to you on 06-13011905 or at lee.verschuren@postnl.nl. If you want to dive straight into the content, you can also reach engineer Cagri Cakir (cagri.cakir@postnl.nl)  
  
**Onze ambitie** Ever since we started our business more than two centuries ago we have been able to disrupt the market and act as a front-runner with technical innovation. Our goal: to keep on being the preferred Deliverer in the Benelux and we believe that technical innovation and logistic intelligence will help us doing so. That is why we work with real-time control systems and applications based on IoT,  AI , Machine Learning and seamless CI/CD. Everything we develop is based on AWS Serverless solutions. Your knowledge, insights and efforts as a Software Engineer are crucial to reach our goals.