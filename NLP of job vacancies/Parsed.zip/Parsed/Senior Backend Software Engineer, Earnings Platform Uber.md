## 
              About the job

**About The Role** Many drivers rely on Uber as their primary and flexible earnings' source. To deliver on our value proposition as a flexible earnings' platform, it is important we efficiently and clearly communicate what has been, and could be, earned to each and every driver on the platform. Information about earnings is the foundation by which drivers are able to set and supervise their goals and make tradeoffs about when and where to drive.  
  
As part of the earnings reliability team, you will have direct responsibility for vital systems and processes. You will take ownership of key features and initiatives in crafting and building high quality, scalable systems in making earnings reliable and efficient. Your work will directly impact the lives of Uber's partners (drivers, couriers), riders, eaters, and operations teams across the globe.  
  
**What The Candidate Will Need / Bonus Points**      
- Build elegant backend platform components for high throughput and low latency distributed systems.
- Experience with challenging problems with innovative design and algorithms.
- You will work with others in the team to maintain the health of our systems and code base, keep development hygienes, refactor and make improvements, keep our systems robust and resilient.
- Drive adoption of best practices in code health, testing, and maintainability.
- Analyze and decompose complex software systems and collaborate with multi-functional teams to influence design for scalability and testability.
- Work with inquisitive and motivated teammates in a fast-paced, collaborative environment.

** Basic Qualifications **
- 5+ years of experience as a software engineer and building large-scale distributed systems
- Coding chops, clean, elegant, bug-free code in languages like Java, GO
- Must have led teams of engineers to deliver autonomously on large multi-functionally driven projects
- Skilled at architecture: Solid understanding of distributed systems architecture - consensus, convergence, data consistency and performance/efficiency constructs
- Strong desire to learn and grow, while building the best in class systems
- Experienced at Cross Team Communication: Strong flair for effective communication and collaboration - you know when to push on and when to step back. We work closely with several groups and supporting these other groups is a key part of scaling our business.
- Push the bar on engineering best practices and help leadership build a strong engineering culture
- Passionate about helping teams grow by inspiring and mentoring engineers.
- Ability to Identify and resolve performance and scalability issues

** What the Candidate Will Do **
- Experience across the full tech stack (backend / mobile / frontend)
- Have experience with working across an organization not just across teams.