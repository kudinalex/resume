## 
              About the job

Running a business is hard, we make it easier. We provide an all-in-one business credit card & spend management platform, built for SMEs. Over 200,000 small businesses have spent more than £8 billion on their Capital on Tap Business Credit Cards.  
  
**The Role** Do you enjoy solving problems with technology and innovative solutions?  
  
We're looking for an experienced Senior Backend Software Engineer to help us build the best credit card and payments product for small businesses. If you're looking for an environment where you're given the freedom to make empowered decisions, research new technologies and learn/share knowledge with your peers. Then keep on reading!  
  
We place a huge emphasis on continual learning and have created an environment where this is possible every day. Internal mobility is important to us and our goal is to help every employee realise their aspirations. Why not check out what you need to do to progress in this role at Capital on Tap - Click here.  
  
**We're looking for experience in...**      
- C#, .Net Core, SQL Server
- Cloud Services, Azure or AWS
- Rest APIs
- Unit and Integration testing
- Agile Methodology
- Mentoring, knowledge sharing, pair programming

**This role can be either remote (within the UK) or hybrid from our London Offices** **What you'll get in return**🏥 Private Healthcare through Vitality  
  
✈️ Worldwide travel insurance through Vitality  
  
🎁 Anniversary Rewards (£250, £500, £1000, 4-week fully paid sabbatical)  
  
👛 Salary Sacrifice Pension Scheme 4-7% match  
  
🏖️ 28 days holiday (plus bank holidays)  
  
📖 Annual Learning Budget  
  
👪 Enhanced Parental Leave  
  
🚲 Cycle to Work Scheme  
  
🚂 Season Ticket Loan  
  
💬 6 free therapy sessions per year  
  
🐶 Dog Friendly Offices  
  
🍫 Free drinks and snacks in our Offices  
  
Check out more of our benefits, values and mission here.  
  
If you want to keep updated on future opportunities at Capital on Tap follow our company page here.  
  
**Diversity and Inclusion** We want to be a place where a diverse mix of talented people want to come and do their best work and most importantly feel included and that they can be their authentic selves. We welcome, consider and encourage applications from anyone that shares this passion.  
  
**How to Apply**If you want to progress your career within a fast growing, profitable fintech then click apply (all we ask for is your CV and contact details) and we will get back to you within 3 working days