## 
              About the job

Each year HelloFresh launches more markets and more brands, and all of those require our technology infrastructure to keep the engine running. SCM is at the core of HelloFresh and the foundation for everything we do. All HelloFresh processes rely on SCM Tech to operate. We manage the contracts with our suppliers, place orders, control the receipt of goods, handle inventory, keep track of the box labelling and production, and keep a close connection with different areas of the company, from Finance to Operations. Our challenge is to improve efficiency and reduce waste across the supply chain. Our vision is to build the world's leading, scalable, fully-integrated, food supply chain management platform.  
  
**The role** Our Backend Engineers assume development and operational responsibility for the HelloFresh fulfilment platform, a global operation system, that serves millions globally to deliver the best experience for our customers and internal users.  
  
Above all, we are looking for people who will make HelloFresh better. We believe there are many different ways of developing skills and we love diverse experiences! So even if you don't "tick all the boxes" but think you'd thrive in this role, we would really like to learn more about you.  
  
**What you'll do**      
- Take ownership of the architecture, design, development, deployment and operations of the microservices you will develop, using DevOps practices, pair programming and other cutting edge methodologies
- Be active, solution-oriented member of autonomous, cross-functional agile teams collaborating with Product Owners, Front-end Engineers, Designers, and Business Intelligence teams
- Having an in-depth understanding of HelloFresh's core product and architecture, and act as ambassador for software solutions offering support and mentorship to colleagues
- Work with state-of-the-art technologies like Kafka, RabbitMQ, Flink, Kubernetes, Istio, and more

**What you'll bring**
- Solid back-end experience within Microservice architecture using at least one of the following: C# & .NET
- Experience working with Docker and container orchestration technologies such as Kubernetes
- As well as experience in CI/CD methods and practices
- Practical experience of TDD, BDD, DDD and distributed architectural patterns
- Background working with event-driven architectures using RabbitMQ and/or Kafka
- Experienced in end-to-end development processes, including unit, integration & functional testing, distributed architecture, application tuning/profiling, and continuous integration
- Experience working with relational and document databases, including PostgreSQL and MySQL
- You thrive in the opportunity to collaborate and mentor team members, while also sharing practical knowledge and trends

**What we offer**
- Comprehensive relocation assistance to move to Saarbrücken plus visa application support
- Healthy discount on weekly HelloFresh boxes
- Annual learning and development budget to attend conferences or purchase educational resources plus access to the HelloFresh Academy
- Subsidised childcare with a professional nannying agency
- Free access to Headspace, biweekly in-house yoga classes (remote since March 2020)
- A diverse and vibrant international environment of 70+ different nationalities
- Additional perks include: Free crash course in German, compensation for advanced external German classes, discounts for our neighboring gym & Urban Sports Club, summer & winter parties, discount on our HelloFresh GO vending machines
- The chance to have a significant impact on one of the fastest-growing technology companies in Europe in an exciting growth phase

#SCMTECH  
  
Are you up for the challenge?