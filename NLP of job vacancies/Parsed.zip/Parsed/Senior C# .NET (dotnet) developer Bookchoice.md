## 
              About the job

**ABOUT BOOKCHOICE**

Bookchoice is a great company to work for. You will be working for one of the biggest e-book & audiobook subscription platforms in the Netherlands, where you can truly make an impact in the lives of many Dutch and Belgian book lovers. Every month, we surprise thousands of engaged members with a curated selection of eight e-books and audiobooks, for them to download and own. We work together with a great team of skilled colleagues to give our customers the best possible experience. Our fantastic office is based in Amsterdam.

Bookchoice is a proud part of Shared Stories Group, together with VBK publishers (largest Dutch book publisher) and Thinium (audiobook production company).

**ROLE DESCRIPTION - WE ARE LOOKING FOR A PERSON THAT:**
      
- enjoys and excels in collaborating within an **small international team**, valuing diverse perspectives and cultural backgrounds. Currently the internal development team comprises a Product Owner, senior Front-end Developer, and senior Back-end Developer, with aspirations for further growth.
- demonstrates ability as a **team player**, contributing actively and positively within a collaborative work setting.
- is proficient in hands-on **C# .NET** development with a demonstrable track record in this domain.
- is capable of handling the entire development (end-to-end) process, from requirements to release, encompassing all stages of software development.
- is comfortable and adept in handling DevOps tasks in **Azure** and **Kubernetes**
- is not** **afraid to contribute to **architectural decisions** as needed.
- is experienced in working within an **Agile** SCRUM framework, embracing its principles and methodologies effectively.
- is based in the Netherlands, preferably in or around **Amsterdam**, facilitating easy access to the work location.

**ROLE DESCRIPTION - WHAT WE CAN OFFER YOU:**

- be a part of our **in-house** e-commerce developement team
- contribute to an incredibly stable and modern platform, based on future proof architecture with very limited amount of legacy
- a nice and cosy office in Amsterdam
- a **full hybrid** work model, allowing for 16 hours per week in-office with your team
- option to **work remotely** for multiple weeks (in consultation with your colleagues)
- company drinks and engaging team activities
- a NS Business card for convenient commuting to the office
- 25 days paid holiday leave per calendar year (based on a 40-hours contract)
- high-performance laptop tailored to your needs
- you will be responsible for designing, developing, and maintaining back-end web applications
- you will participate in the entire software development lifecycle- architecture, data structures, coding, and testing

**QUALIFICATIONS**

- 10 years of experience with C# and .NET Framework
- 2 years of experience with Kubernetes
- 2 years of experience with Microsoft Azure
- Strong analytical and problem-solving skills
- Highly proficient written and verbal communication skills in English

**ABOUT OUR STACK**

Our custom-built platform, developed in C# .NET, is hosted on Azure and leverages a wide range of Azure resources, including:

- Azure functions and webjobs
- Azure Kubernetes Services
- Application Insights
- Azure Queues
- Azure CosmosDB

Our architecture consists of many API microservices, all equipped with their individual MS SQL database. On our platform you will find modules for:

- Payments / renewals
- Shopping cart (subscription + books)
- User management
- Product management (Books and Subscriptions)
- Content management (custom built with MS Blazor)
- Promotion codes

**INTERESTED?**

We invite you to apply through LinkedIn with your resume and convincing motivation.

An assignment could be part of the selection process.

**Unsolicited services or offers from recruitment agencies or intermediaries will not be responded to.**