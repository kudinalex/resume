## 
              About the job

You'll build modern applications for Coolblue's back office. We have a lot of friends, and they crave well-structured data and user-friendly, task-focused applications.  
  
**How do I become a C# Developer at Coolblue?** You regularly participate in brainstorm sessions about user experience, data, and task flow with the UX Designer, Product Owner, and Data Scientists in your team. Besides that you will create disconnected, highly congruent, and testable code that can easily be maintained and is future-proof. Want to become C# Developer at Coolblue? Read below if the job suits you.  
  
**You enjoy doing this**      
- Working with various types of data stores, such as Oracle or AWS.
- Solving problems by using accepted best practices and principles, such as TDD/BDD, SOLID, and design patterns.
- Learning from your colleague developers.
- Recording sprint demo’s.
- Share knowledge during pair programming and constructively comment on pull requests.
- Working on Github and like writing automated tests to ensure software quality yourself.

**You recognize yourself in the following**
- You have at least 3+ years of experience as a C# Developer.
- You have a BSc or MSc in Computer Science or comparable.
- You know your way around automated testing.
- You have experience with software architecture and building .NET applications.
- You have experience with Web API or MVC in .NET Core.
- You know your way around Microservices.
- Working with Scrum/Agile working is second nature to you.
- Having experience with front-end development (React), Javascript, HTML5, and CSS is a plus.
- You're fluent in English

**This is what you’re looking for in a job**
- Money.
- Over 30 training courses at our own Coolblue University.
- Travel allowance and a retirement plan and where-you-work-allowance.
- 25 leave days. As long as you promise to come back.
- A discount on all our products.
- Relocation assistance: from A to Z. We will make sure it goes well and give full support.
- An extraordinarily good work environment with colleagues from all over the world who make you happy, epic (digital) Coolblue parties, pubquizzing, and other activities.
- Room for new initiatives and ideas. We’re always open to those, whether you’ve been with us for a week, a month, or a year.
- A job at one of the fastest-growing companies in the Benelux.
- A picture-perfect office at a great location. You could crawl to work from Rotterdam Central Station. Though we recommend just walking for 2 minutes.
- Working together in an international environment with colleagues from the Netherlands, Belgium, Spain, Brazil, Russia, and Italy, among others.
- Hybrid working: a fine balance between working at the office and working from home. Of course, we’ll help you create the best home-office possible. Including desk chair, laptop, and blue garlands.