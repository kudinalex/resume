## 
              About the job

**Description** To serve its customers globally, Amazon operates businesses and technology platforms that handle some of the largest transaction volumes of any company on earth. The Finance Technology (FinTech) organization works with every part of Amazon to capture, compute, transact, and report their financial events. When a customer orders a banana slicer on Amazon.com in France, watches an episode of Mr. Robot on Prime Instant Video in the US, downloads an e-book on their Kindle from a beach in Brazil, or spins up a spot EC2 instance on AWS in China, they feed into a continuous petabyte-scale stream of global events moving through the company’s technology ecosystem. We harness these data streams to pay Amazon’s suppliers, bill our customers, enable financial analysis and planning, and to report our financial results at many different levels of aggregation to internal and external customers.  
  
The FinTech team operates software platforms that are among the largest in the world by volume and complexity. We interact upstream with all of Amazon’s businesses globally and the majority of our projects are cross-functional. We partner integrally with the CFO organization worldwide, including the central finance functions and line of business leadership.  
  
We are looking for a Senior Software Development Engineer to help us redefine the state of Tax Filing at Amazon. You will design and build large-scale, highly modular and scalable tax platform to help manage tax reporting pipeline for Amazon across geographies. The goal is to eliminate thousands of hours of manual work for Tax and Finance users across Amazon, and bring in process standardization in tax filing process.  
  
You will work across Amazon engineering and business teams, in planning, designing, executing and implementing this new global platform. We’re looking for thought leaders who will drive architectural and design choices, invent new features, develop distributed services, and build a scalable, service-oriented platform for our customers.  
  
We have a team culture that encourages innovation, our engineers and management alike take a high level of ownership for the product vision, technical architecture and project delivery.  
  
We are open to hiring candidates to work out of one of the following locations:  
  
Amsterdam, NLD  
  
**Basic Qualifications**      
- 6+ years of programming with at least one software programming language experience
- 6+ years of non-internship professional software development experience
- 6+ years of leading design or architecture (design patterns, reliability and scaling) of new and existing systems experience
- Experience as a mentor, tech lead or leading an engineering team
- Experience leading the architecture and design (architecture, design patterns, reliability and scaling) of new and current systems
- Experience in professional, non-internship software development
- Experience programming with at least one modern language such as Java, C++, or C# including object-oriented design

**Preferred Qualifications**
- 8+ years of full software development life cycle, including coding standards, code reviews, source control management, build processes, testing, and operations experience
- Master's degree in computer science or equivalent

Amazon is an equal opportunities employer. We believe passionately that employing a diverse workforce is central to our success. We make recruiting decisions based on your experience and skills. We value your passion to discover, invent, simplify and build. Protecting your privacy and the security of your data is a longstanding top priority for Amazon. Please consult our Privacy Notice (https://www.amazon.jobs/en/privacy\_page) to know more about how we collect, use and transfer the personal data of our candidates.  

**Company** - Amazon Development Center (Netherlands) B.V.  
  
Job ID: A2485850