## 
              About the job

**Responsibilities** Job description  

- You design and lead the implementation of highly available, highly scalable, and secure solutions for the energy trading, risk management and portfolio management business using cutting-edge cloud native (azure) technologies
- You are part of a multinational team in an international business locating in 6 European countries
- You are part of the decision process in terms of technologies and technical solutions
- You are responsible for troubleshooting, diagnosing and fixing software issues
- You suggest architecture improvements and recommend process improvements
- You evaluate new technology options and vendor products while ensuring critical system security using best-in-class security solutions

**Qualifications**
- 5+ years of technical experience in a or similar role supporting large scale production systems
- Deep knowledge of software engineering design patterns and clean code practices as well as leveraging strong analytical abilities and creative problem solving
- Experience with the full software development life cycle, including source control system, code reviews, build processes, testing, and operations
- Proven C# and .NET Core knowledge and experience
- Practical experience of MS Azure technologies is a plus
- Business fluent in English and German is mandatory

**Our Benefits** Apart of our inspiring and dynamic international working atmosphere we have following attractive employee benefits to keep you motivated and healthy:  

- flexible working hours
- regular trainings
- E.ON Pension Plan
- private car leasing
- E.ON TeamGas & TeamStrom (subsidized power and gas contracts for employees)
- free parking space
- company credit card
- fitness club and physiotherapy
- job ticket available
- kindergarten places
- family service support
- subsidized canteen

Additionally, we offer  

- the opportunity to shape the new energy world
- the chance to shape E.ONs future
- exciting business challenges to be solved
- a space to develop ideas and create personal impact
- an agile and hands-on environment

Inclusion  
  
It is important to us that people with disabilities have access to a fair application process, providing them with an opportunity to shine. Therefore, our representative body for severely disabled people will be included in the process from an early stage. Please let us know via the application form if you require technical or organisational adjustments during the application process. We will strive to make the required aids available.  
  
Should you not be able to apply online and want to speak someone in person, please contact your local recruiter.