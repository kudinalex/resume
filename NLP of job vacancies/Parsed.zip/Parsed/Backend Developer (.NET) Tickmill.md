## 
              About the job

Are you looking for the next professional opportunity, that will challenge you and advance your career? **Join our team now!**

Tickmill is looking to hire a Backend Developer (.NET) to join our rapidly expanding team.

Join a high-caliber team and contribute to its success with your passion, hard-work and positive attitude.

**About Tickmill. **

Tickmill is an award-winning, multi-regulated broker offering a wide range of asset classes including CFDs on Forex, Stocks, Indices, Commodities, Cryptocurrencies and bonds, as well as Exchange Traded Derivatives (Futures & Options).

The Tickmill Group was established in 2014, and employs over 280 individuals through its offices in London, Cyprus, Estonia, South Africa and several other regional offices globally.

Our philosophy is based on trust, transparency, and diversity, reflected in both our workplace culture and outstanding customer support. Our employees, a multilingual team of highly skilled professionals from every continent, are the backbone of the company. Their hard work and dedication are what makes it possible to rank among the best in the industry. Tickmill offers a competitive benefits package, hybrid work model, team-building events, and many opportunities for professional growth.

**What the job looks like?**

** **

The Backend Developer (.NET) will have the opportunity to:

- Design, develop and support backend services with a focus on integrations with other systems, services.
- Support and improve our quality processes by developing automated unit tests and performing code reviews.
- Collaborate with internal/external teams throughout the integration process.
- Identify, correct bottlenecks and fix bugs.
- Help maintain code quality, organization, and automatization.
- Stay up to date with new technology trends, applications, and protocols.

**What will you need to be able to do the job?**

- Degree in Computer Science, Engineering, or a related field.
- Good understanding of object-oriented programming and design patterns.
- 3+ years of software development experience, ideally in C#.
- Ability to assess, troubleshoot and debug integration issues.
- Good understanding of code versioning tools.
- Excellent analytical, and problem-solving skills.
- Proficient in English language with excellent written and verbal communication skills.

**It will be considered as a plus if you have:**

- Experience working in cloud infrastructures like AWS or Azure.
- Understanding of CI/CD, unit testing, integration testing.
- Experience with Relational Database Management Systems.
- Experience within the financial markets Industry on a similar IT field.

**By joining us, you can expect:**

- A **Unique Opportunity** for a career in a global, fast-growing company.
- Attractive **remuneration package** based on qualifications and experience.
- An international team of **skilled colleagues** and a **modern and professional work environment.**
- Multiple events to bond with the team and the group through **Quarterly/Semestrial Team Activities** for all the Company.
- Opportunities to **learn and grow** through our “Employee Training & Development program”.
- A great chance to focus on your **Health and Wellness **through our Sports compensation program.
- Birthday **Half Day off plus a gift**.
- Weekly **complimentary breakfast**.
- **Hybrid working schedule.**
- **Loyalty benefits.**

**Make your next Career step and apply NOW!**

\**Due to the great number of applications, we receive for each of our open vacancies, we are unable to respond on an individual basis.*