## 
              About the job

**What To Expect** Do you want to work on Tesla's IoT platforms that support Powerwall, Megapack, Solar Roof, Supercharger, Autobidder, and Virtual Power Plants? Do you want to work with functional programming, streaming data, and distributed systems? Do you want to work with Scala, Akka, Reactive Streams, InfluxDB, PostgreSQL, and Kubernetes?  
  
Tesla is looking for software engineers to build the cloud services that power these products, driving the worldwide transition to sustainable energy. These platforms provide real-time monitoring, optimization, and control of distributed, renewable-energy assets, including generation, storage, grid services, and electric vehicle charging. You must enjoy thinking in systems and working on challenges related to the availability, reliability, scalability, and security of distributed software systems.  
  
**What You'll Do** - Design, develop, maintain, and operate distributed software systems that incorporate real-time and streaming data for the monitoring, aggregation, and control of millions of IoT devices
- Characterize complex problems related to the scalability, reliability, performance, and security of production systems
- Test the performance, scalability, and reliability of software systems at scale, including developing the services to support this testing
- Provide technical leadership, foster collaboration, and drive initiatives to completion
- Maintain the values of the team which include engineering excellence, curiosity, a bias for action, self-awareness, inclusivity, and vulnerability
**What You'll Bring** - Several years industry experience designing, building and supporting large scale systems in production
- Experience building large scale distributed fault tolerant services
- Excellent understanding of low level operating systems concepts including multi-threading, memory management, networking and storage, performance and scale
- Strong CS fundamentals including data structures, algorithms, and distributed systems
- Systems programming skills including multi-threading, concurrency, etc. Fluency in Akka or Scala preferred
- Track record of identifying and implementing creative solutions
- Experience with cloud infrastructure - AWS, Azure or Google Cloud
Tesla