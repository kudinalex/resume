## 
              About the job

**Reporting to:** Engineering Manager  
  
**Location: ** London  
  
**Who We Are And Why We Exist** At Liberis – merchants matter most! We’ve been on a mission to provide small and medium businesses (SMEs) with accessible and responsive finance since 2007. SMEs account for most businesses worldwide and are critical contributors to job creation and global economic development. They represent about 90% of businesses and more than 50% of employment worldwide. Despite this, more than three quarters (77%) of SME businesses last year were unable to secure the traditional bank financing they desperately needed to grow and thrive. This has created a $5 trillion funding gap for SMEs globally.  
  
That’s where Liberis steps in! To best help small businesses, Liberis has built the leading global embedded finance platform. Through this, Liberis provides partners with the technology and financial solutions necessary to offer personalised and accessible funding to their small business customers.  
  
To date with ~20 global strategic partners and direct reach to more than 1 million small businesses, Liberis has provided $1 bn of funding in over 50,000 transactions, enabling more than 100,000 jobs to be created and saved. We are making a genuine difference to your local pub, hairdresser and online retailer!  
  
We are in a very exciting period of growth, in the UK and internationally, with teams based in London, Nottingham, Stockholm, Atlanta, Munich and remotely. We are looking for talented and ambitious individuals to help us reshape business finance. How we work is as important to us as what we do – exemplified by our behaviours:  
  
#1 **Merchants matter most** – our success is tied to our merchants' success  
  
#2 **Act like time is running out **– the fastest company in a growing market will win  
  
#3 **Own every outcome **– the hardest problems we face are yet to be solved  
  
#4 **Communicate directly **– we don’t have time to beat around the bush  
  
#5 **Prove it **- every feature we build, decision we make and action we take, matters  
  
#6 **Empathy always** - Liberis wins when every employee thrives  
  
**If our mission and behaviours resonate – get in touch!** **Who Are We** We are the Engineering team. We exist to build the products and automation that will drive Liberis’ exponential growth in the embedded finance market.  
  
There are 80 of us based around the UK, we split ourselves into domain aligned teams working on a specific part of our product offering: Merchant Experience, Partner Experience, Internal Tooling, Funding, Decisioning, Pricing, & Targeting; as well as across a few supporting functions: DevEx, Data, Architecture, & support.  
  
Our mission is to build composable, modular technology platforms that will close the global SME funding gap.  
  
We are collaborative (with each other, and with our users), and we value moving fast by fixing things.  
  
Intrigued and want to know more? Head over to Life at Liberis!  
  
**Who are you? **      
- You are an expert programmer, with multiple years of experience in environments like ours.
- You are comfortable working in the early stages of defining and solving business problems. You value collaboration and responding to change over negotiation and rigidly following a plan.
- You might be a specialist in one area of our tech stack (mostly C# .net, Node, React, Azure) but you’re willing to learn and get stuck in anywhere.
- You know how to contribute to a high performing team. You always optimise for team performance over individual performance.

**Responsibilities**
- Use continuous delivery practices to deliver high-quality software and value to end users as early as possible
- Work in collaborative, customer obsessed teams to build fantastic experiences for internal and external users
- Contribute to our distributed, global architecture while defending our quality and performance requirements.
- Build and run software, exemplifying DevOps culture.
- Take part in our entire software lifecycle, from ideation, to building, to maintenance, to collecting feedback and improving.
- Mentor junior engineers.

**We think you’ll need **
- Professional experience writing code in two or more programming languages. A willingness to learn our tech stack - mostly C# .net, Node, React.
- An understanding of working with Agile methods, such as Extreme Programming, Kanban, or Scrum.
- Experience mentoring more junior team members.
- Multiple years of experience in an environment that is in some way similar to ours.
- Resilience in early stage business situations, where requirements are evolving and experimentation is required.
- Bonus points if you have experience of cloud technologies (we mostly use Azure); experience using highly collaborative methods such as ensemble, mob, or pair programming; experience writing financial software; or experience with Test Driven Development.

**What happens next?** Think this sounds like the right next move for you? Or if you’re not completely confident that you fit our exact criteria, apply anyway and we can arrange a call to see if the role is fit for you. Humility is a wonderful thing, and we are interested in hearing about what you can add to Liberis!