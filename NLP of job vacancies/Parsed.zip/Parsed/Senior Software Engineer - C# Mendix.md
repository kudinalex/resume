## 
              About the job

**Mendix – The Leading Low-code Application Development Platform** The Mendix Platform uses visual modeling to abstract long-form coding out of application development. Our customers use Mendix to create and deploy better software for the enterprise, faster. Mendix is collaborative - the people who use the software and the people who build the software work together throughout the development process.  
  
Read our Customer Stories to learn more about the wealth of software and solutions global organizations have built with the Platform.  
  
At Mendix we strive to maintain a diverse, open, and safe working environment where people can be their true selves. We value every voice, celebrate individuality, and appreciate the diversity of thought and experience. People who work here are driven, smart, and really good at what they do.  
  
As this market evolves, we encourage people of all skill levels to work with the platform, both for clients and candidates. Apply today to discover how you can make a meaningful impact with Mendix.  
  
**About The Role** Are you a proactive and hands-on developer with a demonstrated ability working currently as a C# developer? Do you have a passion for developing powerful, cross-platform Integrated Development Environments (IDEs) that foster collaboration between business users and professional developers? Do you thrive on simplifying complex technical challenges, enabling non-technical individuals to efficiently build exceptional applications? If you have superb communication skills and the ability to see the full picture beyond individual tasks, then this opportunity is perfect for you!  
  
Join our dedicated team and take full ownership of delivering and supporting the core of our development environment for the Mendix platform: Studio Pro. In this role, you will have the opportunity to showcase your proactive personality and hands-on approach to development.  
  
**Responsibilities**      
- Demonstrate proficiency in C#, showcasing a solid understanding of other programming languages is a plus
- Embrace challenges by meticulously understanding and deconstructing them into comprehensible code
- Employ an iterative approach to break down challenges and construct solutions with short feedback cycles
- Investigate existing functionality to refactor and introduce new features seamlessly
- Take ownership of your work's quality by proactively identifying risks and conducting thorough testing
- Maintain a continuous learning mindest, consistently innovating and staying up-to-date in your field
- Thrive in a collaborative team environment, valuing teamwork over individual isolation

**Required Experience**
- Solid understanding of the .NET framework and proficiency in C# programming language (5 years+ experience)
- Experience with XAML and WPF (Windows Presentation Foundation)
- Extensive expertise in developing desktop applications and backend logic
- Familiarity with multi-platform development, including experience with macOS.
- Knowledge and experience in Domain Specific Languages (DSL) and metamodeling.
- Proficient in unit testing practices and frameworks
- Experience in applying design patterns to create robust and scalable solutions
- Familiarity with agile methodologies and iterative development practices

**Experience With The Following Is a Plus**
- Proficiency in building web applications using .NET technologies
- Demonstrated ability to construct frameworks for widespread usage
- Familiarity with build tools such as Jenkins and Bamboo, and hands-on experience with continuous integration and deployment practices
- Proficiency in building Mendix applications

**Why should you join? **
- Build tools for other developers: As part of our team, you will have the opportunity to build tools and frameworks that will empower other developers. Your work will have a direct impact on improving the efficiency and productivity of the development community, allowing them to create exceptional applications
- Solve patterns, not simple problems: We tackle complex challenges that require innovative solutions. Joining our team means you will have the chance to work on intricate patterns and architecture, going beyond simple problem-solving. We encourage you to think critically and find elegant, scalable solutions that address the core challenges faced by our customers
- Think big and holistic: We value a big-picture mindset, encouraging you to consider the broader impact of your work. By taking a broad approach, you contribute to creating a flawless and comprehensive development environment. Our goal is to enable customers to achieve their objectives effectively
- Enable more people to build applications faster and easier: We're on a mission to make app development accessible to a wider audience. By joining us, you become part of a ground-breaking journey, simplifying the development process and empowering more people, including non-technical individuals, to build applications faster and easier. Your work bridges the gap between business challenges and technical solutions

*If you see a job description and think, “I’d be perfect for that” but your experience doesn’t align perfectly with the qualifications – don’t let that hold you back. We’re always eager to hire talented, passionate candidates – so give it a try and apply. **Equal Employment Opportunity Statement** Mendix/Siemens is an Equal Opportunity and Affirmative Action Employer encouraging diversity in the workplace. All qualified applicants will receive consideration for employment without regard to their race, color, creed, religion, national origin, citizenship status, ancestry, sex, age, physical or mental disability unrelated to ability, marital status, family responsibilities, pregnancy, genetic information, sexual orientation, gender expression, gender identity, transgender, sex stereotyping, order of protection status, protected veteran or military status, or an unfavorable discharge from military service, and other categories protected by federal, state or local law.  
  
**EEO is the Law** Applicants and employees are protected under Federal law from discrimination. To learn more, Click here .  
  
**Pay Transparency Non-Discrimination Provision** Siemens follows Executive Order 11246, including the Pay Transparency Nondiscrimination Provision. To learn more, Click here .  
  
**California Privacy Notice** California residents have the right to receive additional notices about their personal information. To learn more, click here .