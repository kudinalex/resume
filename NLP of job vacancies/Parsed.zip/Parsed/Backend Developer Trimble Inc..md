## 
              About the job

**Job Title:** Backend Developer (m/f/d)  
  
**Location:** Höhenkirchen near Munich, Germany  
  
**Division:** Trimble Advanced Positioning  
  
You will join the Trimble development team in Höhenkirchen near Munich, Germany. We are Trimble's center of excellence for GNSS (Global navigation satellite system) precise positioning. You will be responsible for developing new and enhancing existing software solutions on the base of state-of-the-art technologies.  
  
We are a highly international team that adapts quickly to new business requirements. We need people who are comfortable tackling new problems, innovating solutions, and interacting with our marketing team and end customers. You are creative, motivated, able to take responsibility and support the applications you create.  
  
**Your Expectation** Our GNSS precise positioning solutions are used by thousands of users. To provide the best positioning experience Trimble owns and operates a worldwide network of GNSS reference stations to create corrections signals.  
  
If you are interested in developing a modern .NET based microservices backend for processing real-time GNSS data you will find the innovative environment for your aspirations.  
  
**Your Key Responsibilities Are**      
- Design and build for performance
- Architecture and build for availability
- Ensure automatic scalability
- Analysis of different data formats
- Maintenance of distributed microservices
- Safeguard APIs and User Access management

**To Achieve**
- Highest accuracy and reliability: Our server software enables highly accurate GNSS positioning for a large number of field users all over the world. Our focus is on continuous improvement to achieve state of the art performance. In parallel we prepare cloud based services to take over functionality from the on-premise server application.
- Performance and robustness of the backend services: GNSS corrections need to be available in 1Hz real-time with high reliability.
- Availability all over the world: Our customers depend on the accuracy and on the availability of our correction services for their daily work. 100% up time delivering correct data is our ongoing motivation.
- State-of-the-art technology: Extending our current portfolio into highly scalable applications utilizing C#, .Net, ASP.Net, cloud services, Docker, Kubernetes as well as modern Pub/Sub Messaging systems and web based visualization.
- Effective data structures: Depending on the technology of the connecting device, like L-Band, IP, IoT or GSM - we need to provide different data formats for best performance regarding communication and monitoring.
- Hosted network services: With Trimble RTX and Trimble VRSNow we host our own services that need to be maintained and extended with specialized features.

**Desired Skills And Experience**
- University degree in computer science, engineering, physics, mathematics, geoinformatics or similar technical discipline.
- In depth knowledge of C# or a similar OO language. Experience in writing and consuming web services. Familiarity with Rest, Docker, Kubernetes as well as pub/sub messaging.
- Demonstrated experience as a developer in a .Net environment utilizing Microsoft Visual Studio, Git as source repository and an appropriate build chain.
- A background in GNSS technology would be a benefit, but is not a must. As a center of excellence for high precision positioning we provide extensive training for our employees.
- Readiness for cross-team collaboration with other Trimble software engineering teams. Able to communicate with the customer companies to discuss technology and progress.
- Up to date with current trends and patterns going on in the world of Cloud development as it changes rapidly.

Are you the candidate we are looking for? Don’t hesitate to apply. We are looking forward to your application.  
  
**We Offer**
- The thrilling opportunity to join our innovation driven R&D team focused on developing new software positioning products
- An inspiring work culture in an international team of experts with more than 100 colleagues from 30 countries
- A long-term, secure position with an equitable compensation and Stock Purchase Plan
- Modern workplaces with qualitative tools and flexible working hours
- Free membership in Munich's prime fitness studios and weekly business workout on site
- Hybrid work environment with a focus on team spirit.

**About Our Trimble Advanced Positioning Division** Trimble’s Advanced Positioning Division is a leader in autonomous technologies that help our customers in automotive, agriculture, Construction, and other emerging vertical industries operate more efficiently.  
  
Check out Trimble RTX™ here: **https://youtu.be/jSS2cQ6DC3w ** **Trimble’s Inclusiveness Commitment** We believe in celebrating our differences. That is why our diversity is our strength. To us, that means actively participating in opportunities to be inclusive. Diversity, Equity, and Inclusion have guided our success while moving our desire to improve. We actively seek to add members to our community who represent our customers and the places we live and work.  
  
We have programs to ensure our people are seen, heard and welcomed and, most importantly, that they know they belong, no matter who they are or where they are coming from.