## 
              About the job

At Rovio you will get to work with multiple groundbreaking IP’s including one of the most famous game IP’s in the world: Angry Birds! We craft joy with player-focused gaming experiences that last for decades. In order to do that, we know that people need to bring their own joy to what we do. That’s why we value work-life balance, say no to crunch culture, and welcome people from all walks of life to join the flock. Today, we are a proud team of 500+ caring and talented professionals representing over 50 different nations.  
  
We trust our teams to work autonomously by providing them the right tools and level of responsibility. We believe in our teams to remain creative and to keep learning – as well as ensuring everyone has opportunities for personal growth.  
  
The Server development Craft is responsible for designing and implementing scalable architectures with .Net Core on AWS. The team believes in well-crafted software that increases the product value without compromising the productivity. Clean code, test driven development and SOLID principles are a reality applied to any project. The team is located in Stockholm and works in a hybrid model (2 days per week onsite).  
  
Currently not based there? No problem at all, we will help you with the relocation and work permit if needed!  
  
We are looking for a Senior Server Developer to join the team of 4 professionals. As a Senior Server Developer, you will primarily take care of developing features and maintaining the infrastructure of Angry Birds 2 game, but also participate in backend development of new game projects.  
  
**You will have impact and fun at work by doing:**      
- Design, implement and test game backend functionality for games using C#, .Net Core, PostgreSQL, Redis
- Create, maintain and operate the game server cloud infrastructure on AWS with Terraform
- Ensure that game backends are efficient, secure and scale well
- Work with real-time gaming technologies for multiplayer games
- Integrate other cloud services to game servers
- Participate in designing backend solutions working closely with the client team
- Work as a team with other developers, designers and artists

**Experience and skills we are looking for:**
- Solid server programming experience with C# and .NET Core where you have implemented solutions for games to handle millions of players
- Good knowledge and hands on experience of cloud platforms like AWS
- Experience in high-load services
- Good understanding of SQL and NoSQL databases
- Working experience with SOLID principles and TDD
- Understanding of game architectures and technologies

**It would be nice if you also have the following skills:**
- Hands on experience with Kubernetes

**What’s in it for you:**
- Opportunity to work on a large scale where your work impacts millions of people
- Chance to apply TDD and be an advocate of high quality code
- Keep up-to-date with emerging technologies and industry trends
- No crunch - we value work-life balance

**Interview process:**
- First meeting: You will meet the TA Partner to get acquainted and learn more about Rovio and the specifics of the role
- Call with a Hiring manager: We will deep dive into your skills and background and also discuss what motivates you. This is also an opportunity for you to learn more about Rovio and the specifics of the role
- Assignment: We’d like to learn more about your hard skills through a relevant take home task, which takes a few hours
- Technical interview: We will invite you to present the assignment results to your colleagues in the Server development Craft for an in-depth conversation
- Final rounds: You will meet the Technical Director and Game lead. Our aim is to get a clear overview of your collaboration and communication skills, how you would fit with our working culture, your ambitions and where we can help you develop.