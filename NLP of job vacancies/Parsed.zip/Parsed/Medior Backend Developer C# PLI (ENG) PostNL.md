## 
              About the job

Always been curious how web shops know when an order can be delivered in the check-out flow? Platform Logistical Information collects logistical information from various sources, combines it with smart business logic and gives applicants the right answer to their questions, which can amount to 15 million APIs calls per day. This includes the delivery day, delivery time, possible delivery options and even sustainability options for the delivery method. As a backend developer, you will help develop a mission-critical application that uses  
  
**Wat ga je doen?** As a backend developer, you will be part of the Platform Logistical Information team (P.L.I.). This team is building a platform in which logistical information is collected and enriched in order to provide it to various external stakeholders and internal stakeholders so that a choice can be made based on this information. For consumers, we want to always be able to tell you the right information about a delivery as quickly as possible, when and when it will arrive at your doorstep. For other applications, we are the source for location information of both PostNL locations, so customers and consumers know where to go for various PostNL services. Because customers make a choice based on the information provided by Platform Logistic Information, we are a mission critical platform where uptime and performance continuously play an important role. You will be part of a DevOps Scrum team with 8 team members. Together, you will design and develop the solution using an AWS Serverless infrastructure. We use C# as our programming language and AWS Services such as DynamoDB, SQS, SNS, Lambda, and API Gateways.  
  
**Wat breng jij mee?** You have previous years' experience with #C combined with cloud practices. Interest or experience with CI/CD would be very nice. Furthermore, you are curious and always try to find new ways to solve something. You feel comfortable in a team with different nationalities and to speak English. The team is informal and has good technical knowledge, which they like to share. We love to work out new ideas together where everyone's expertise comes in handy.  

- At least 3 years of working experience developing software with C# and AWS.
- Experience/interest in CI/CD is a plus.
- Experience of working in an agile environment.
- You enjoy thinking about how we can use new technologies and work smarter.
- A team player, who wants to be part of an enthusiastic, multidisciplinary Scrum team. The more experienced engineers will help you grow in the areas of your interest.

**Wat bezorgen we jou?** As a candidate, you will find that we are in a unique phase as an organisation, with many "green field" environments. We are very ambitious in the digital supply chain management department, but you will not be alone in meeting both your own and team goals. Besides the support of colleagues from different IT disciplines and the engineering community, you will find that your colleagues from other fields are there to support you. Together, we help PostNL become a Logistics Tech company. Your development goes beyond this role. We encourage your growth as a person and provide the right advancement opportunities. We also facilitate the necessary AWS training if needed.   
  
You will also receive:   

- A basic salary of maximum €6.062 (scale 10/11) based on a 37-hour working week but you can also work 32 hours.
- The team works a maximum of 1 or 2 days at the office (The Hague HS). You will receive an NS Business card for your travel expenses but of course also an engineering laptop including telephone, and a home office allowance of 45 euro net.
- 25 holidays and 8% holiday pay. You can buy an extra 5 days.
- We grow in our agile teams where you get the freedom to take ownership in growing with and as a team. You and your teammates shape the way you work together, continuously learning and growing with a daily shot of fun and challenging puzzles;

Interested?  
  
PostNL wants to be the delivery company of choice for everyone. So everyone is welcome with us and it doesn't matter where you were born, what you believe in or who you love. We care about your unique talent.  
  
For more information about the vacancy and the process, Lee Verschuren, the recruiter for this position, is happy to speak to you on 06-13011905 or at lee.verschuren@postnl.nl  
  
**Onze ambitie** Over the past 220 years, we have been able to grow with the market and even be one step ahead. As a team, we deliver an average of 1.1 million parcels a day. Our goal: to remain the delivery company of choice in the Netherlands. We believe that being at the forefront of technology and using logistics intelligence will help us achieve that goal. Therefore, we develop in-house AWS serverless solutions with the help of machine learning and innovative technologies to meet all our stakeholders' needs. In your role as a backend developer, you will be at the centre of all this.