## 
              About the job

is Germany's best-known AI company. We develop neural networks that help people work with language. With DeepL Translate and DeepL Write we have created the world's best systems for translating and enhancing text and made it available to businesses and individuals.  
  
**Our goal is to overcome language barriers and bring cultures closer together.** **What distinguishes us from other companies?** DeepL (formerly Linguee) was founded by developers and researchers. We are focused on developing new, exciting products, so we spend a lot of time actively researching the latest trends and technologies. We understand the challenges of developing new products and try to meet them with an agile and dynamic way of working. Our open and positive workplace philosophy enables employees to feel comfortable and thrive in their roles. We use modern technology in our daily work - not only to translate texts, but also to create the world's best dictionaries and solve other language-related problems.  
  
**What will you be doing at DeepL?** Thanks to our unique neural networks, DeepL is able to deliver the world's best quality translations. To keep it that way, we are constantly improving our apps and adding exciting new features - and this is where your experience in developing sophisticated software comes in.  
  
You will be developing C# backend services (running on .NET Core on Linux) for products that help millions of people and businesses in their everyday lives. You will be part of a highly motivated team that values easy to maintain and efficient code. Important design decisions are made by the whole team in open discussions.  
  
**Your responsibilities**      
- Design, implement and maintain reliable, scalable and efficient backend services for DeepL's products
- Contribute to monitoring and debugging the services in production, e.g. by defining expressive metrics and ensuring expressive logs
- Collaborate across teams to define shared interfaces and ensure smooth operation in production

**What we offer**
- Meaningful work at scale: We break down communication barriers worldwide and bring different cultures closer together
- Code reviews and focus on high quality
- A highly engaged team with transparent decision making. We value collaboration and efficiency, but we also value trust, empathy, inclusivity and an overall 'people first' approach
- Flexible working: with office hubs in Cologne, Berlin, Munich, Leipzig, London and Amsterdam, you can choose where and how you work. We offer fully remote work from UK/DE/NL/PL, no strings attached, no 'to be reviewed'- DeepL is a remote positive company now and forever
- Work from abroad up to 30 days/year, Urban Sports Club, personal development budget, furniture for your home office, 30 days paid holiday
- Regular innovative team building events - internationally!

**About You**
- Several years of experience in software development
- Strong proficiency of C# and .NET Core
- Experience of server-side frameworks, preferably ASP.NET Core
- Solid understanding of computational complexity and common data structures
- Strong team player with the ability to develop and drive own ideas and work independently on a feature
- Degree in Computer Science or equivalent, alternatively several years of professional experience in software development
- Fluent in English

**Ideally, you have one or more of the following qualifications:**
- Experience developing services for public API products
- Experience in developing and operating large-scale, high-reliability architectures
- Experience with Kafka
- Experience with SpiceDB
- Experience with CockroachDB
- Experience with Cassandra
- Experience with ClickHouse
- Integration with external SAAS services
- Experience with Operational transformation (OT)

**We are looking forward to your application!**