## 
              About the job

FINBOURNE Horizon is our suite of partnerships and interfaces with third party vendors and service providers that enables clients to adopt additional functionality within LUSID. 

We are looking to hire engineers to work on building integrations with our partners, vendors and service providers across a broad technology stack and set of integration patterns.

Founded in 2016, FINBOURNE Technology has grown globally and now stands at over 200 employees across multiple jurisdictions. We have opened an Irish entity, to support with our global expansion and operations. With a small team now established, this role will have an opportunity to make an impact and join us on the journey.

**Key responsibilities:**

- Ownership of design and implementation for integration solutions
- Manage relationships with external partners and vendors
- Deliver robust technical solutions that form part of the core product
- Collaborate across multiple engineering teams and work across a diverse technology stack

**What skills, experience and qualifications we require: **

- 3-6 years of commercial experience using C#
- Practical experience of working with Docker and Kubernetes
- Experience of delivering software in a CI/CD environment
- Experience of working with SQL in a commercial environment, preferably PostgreSQL or MS Sql Server
- Experience running software projects with a multitude of stakeholders across multiple time-zones
- Excellent communication skills and the ability to discuss complex topics with technical and non-technical audiences
- Experience of working within Financial Services would be advantageous but not essential, in particular working with market data vendors, pricing/analytics or fund administration/custody services.

**About FINBOURNE**

We are a young, dynamic financial technology company aiming to re-engineer the world of investing to make it clearer, faster and more cost effective for everyone.

We are looking for our future architects, engineers and ultimately leaders to join us on this journey.

At FINBOURNE, we offer a hugely supportive environment to build a career, with continuous learning and development opportunities. We have a collaborative culture of testing and exploring problems together to find the best evidence-based solutions. We respect your independent thought, your intellectual curiosity and your opinion.

Our solution is open, API first and developer friendly – a true first for the asset management industry. You can see what our team is busy building – we’ve published our Software Development Kits in five languages on Github: (C#, Java, Javascript, Python, Angular).