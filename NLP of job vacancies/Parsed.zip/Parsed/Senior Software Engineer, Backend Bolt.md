## 
              About the job

We are looking for an experienced **Senior Backend Software Engineer **to work on unique product challenges: complex algorithms for demand prediction, optimal real-time pricing, routing, fraud detection, distributed systems and much more.  
  
**About Us** Bolt is one of the fastest-growing tech companies in Europe and Africa, with over 100 million customers in 45+ countries. We’re a global team of more than 100 nationalities joined on a common mission – to make cities for people, not cars. And we need you to make it happen!  
  
**About The Role** As a **Senior Software Engineer**, you will be responsible for architecting, designing, developing, and deploying Bolt's growing backend systems. That will mostly happen via coding in Node.js and TypeScript (PS: no previous experience with Node.js is needed).  
  
**Your daily adventures will include:**      
- Architecting, designing, developing, and deploying Bolt's growing backend systems
- Contributing ideas and constructive feedback to our product development roadmap
- Helping lead features/initiatives from idea to positive execution
- Working closely with Product to slice and dice scope and deliver piece by piece
- Sharing your knowledge by giving tech talks, and promoting appropriate tech and engineering best practices in and outside of the team

**About you:**
- You have experience of thriving in an environment that has a fast customer-feedback cycle and having empathy for the end-user
- You are great at making data-driven and metric-driven decisions
- You have a drive for leading initiatives and features till the end, even if the last mile is the hardest
- You feel at home with microservice architecture and you are experienced in API design
- You have strong principles towards writing clean, simple, secure, and maintainable code
- You have a deep understanding of how to write readable, testable, maintainable, and performant code

Experience is great, but what we really look for is drive, intelligence, and integrity. So even if you don’t tick every box, please consider applying if you feel you’re the kind of person described above!  
  
**Why you’ll love it here:**
- Play a direct role in shaping the future of mobility.
- Impact millions of customers and partners in 500+ cities across 45 countries.
- Work in fast-moving autonomous teams with some of the smartest people in the world.
- Accelerate your professional growth with unique career opportunities.
- Get a rewarding salary and stock option package that lets you focus on doing your best work.
- Enjoy the flexibility of working in a hybrid mode.
- Take care of your physical and mental health with our wellness perks.
- Some perks may differ depending on your location.