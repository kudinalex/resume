## 
              About the job

On our path to becoming the world’s favorite way to shop, we’re assembling an unparalleled global talent network, accelerating individual careers, and disrupting entire industries. We are on a mission to liberate humanity from all the meaningless time spent managing their purchases and finances, so they can do more of what they love. We’re in search of global talent eager to embrace our atmosphere and defy their own expectations.  
  
Engineering at Klarna is an inspired, customer focused community, dedicated to crafting solutions that redefine our industry. Working in small, highly collaborative Agile teams, you and your team will have a clear mission and ownership of an important outcome that supports Klarna and our customers. At Klarna we optimise for quality, flow, fast feedback, focussing on end-to-end ownership, continuous improvement, testing, monitoring and experimentation. We aim for teams that are inclusive, helpful, and have a strong sense of ownership for the things they build. Our engineers make some of the most significant decisions for the company and we are looking for bold, open and curious developers.  
  
Want to be part of the change? We're expanding several of our engineering teams, including; teams working on our core checkout product, payment services, fraud prevention, or improving our billing service and shipping credentials to name a few.  
  
**What What You Will Do**      
- Work on a specific problem space critical to Klarna’s current needs with opportunities to switch teams as you and our fast-paced business grow and evolve
- Bring fresh ideas from all areas, including information retrieval, large-scale system design, data storage/processing, security, artificial intelligence, UI design and mobile development
- Develop as a professional in an entrepreneurial organisation that provides opportunity to work with your areas of interest.
- Use state of the art technology to solve real problems for our customers at a massive scale.
- Design, develop, test, deploy, maintain and improve, you own the full life-cycle of your code - you write it, you own it.
- Share your knowledge and help the team evolve best practices
- Work in small autonomous teams with short release cycles.

**Some of the technologies you’ll get to work with;**
- Java (latest versions)
- Spring and Spring Boot
- Docker and Kubernetes
- Kafka
- PostgreSQL, DynamoDB, Elastic search
- Microservices architecture on AWS

**To succeed in this role, we think you should have;**
- Extensive software development experience with one or more general purpose programming languages including but not limited to Java
- Great problem solving abilities
- Working proficiency in English

**What We Can Offer You** **Culture -** You'll have an opportunity to work with talented people from 90+ different countries in our offices in Stockholm city center.  
  
**Learning -** We have a learning and development focused environment with an emphasis on knowledge sharing, training, and regular internal technical talks.  
  
**Compensation -** You’ll receive an attractive salary, pension, and insurance plans, plus we offer all of our employees an opportunity to invest in a RSU program and own a stake of the company. You’ll also receive 30 days annual leave and since we recognise that life is about more than work, we also offer benefits for gym memberships, marathons, and all sorts of activities that promote physical health. We also have generous parental leave (for men and women).  
  
**Relocation:** Unfortunately we do not offer relocation support for these roles but we would be happy to provide visa support when necessary.  
  
We also believe in contributing back to the open source community. You can find some of our work here https://github.com/klarna .  
  
**How to apply:** please send us your CV or Linkedin profile in English  
  
**What We Offer** **Diversity & Community** With our diversity of skills, perspectives and backgrounds, we can create, innovate, and disrupt like no other. Diversity is part of who we are, and essential to our success.  
  
**Ownership & Impact** Here, every voice matters. We’re organized into hundreds of small teams, each run like a start-up, focused on their own problem-space.  
  
**Trust & Collaboration** Successes and failures are won together at Klarna in a melting pot of teams. Win, lose, and learn, we’re on this path together.  
  
If you love what you do, you should love where you do it. We appreciate that everyone’s different and has their own preferences of where and how to work. We genuinely believe in the power of regular face-to-face interactions in building close connections with our teams, but we also strongly believe people can work effectively remotely. This means that combining both is the key to success.  
  
At Klarna, You can choose between working from the office, hybrid within your employment country, or even outside of it for up to 20 working days per year. Flex it up!   
  
**Challenges & Rewards** We take a very Swedish approach to benefits. Support for parents, health and wellness perks—we’ve got you covered.  
  
**About Klarna** Since 2005 Klarna has been on a mission to revolutionize the retail banking industry. With over 150 million global active users and 2 million transactions per day, Klarna is meeting the changing demands of consumers by saving them time and money while helping them be informed and in control. Over 450,000 global retail partners, including H&M, Saks, Sephora, Macys, IKEA, Expedia Group, and Nike have integrated Klarna's innovative technology to deliver a seamless shopping experience online and in-store. Klarna has over 6,000 employees and is active in 45 markets. For more information, visit Klarna.com  
  
It is our commitment that every qualified person will be evaluated according to skills regardless of age, gender, identity, ethnicity, sexual orientation, disability status or religion. Please refrain from including your picture and age with the application.