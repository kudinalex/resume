## 
              About the job

*Grammarly is excited to offer a **remote-first hybrid working model**. Team members work primarily remotely in the United States, Canada, Ukraine, Germany, or Poland. Certain roles have specific location requirements to facilitate collaboration at a particular Grammarly hub.**All roles have an in-person component: Conditions permitting, teams meet 2–4 weeks every quarter at one of Grammarly’s hubs in San Francisco, Kyiv, New York, Vancouver, and Berlin, or in a workspace in Kraków. **This flexible approach gives team members the best of both worlds: plenty of focus time along with in-person collaboration that fosters trust and unlocks creativity.* *Grammarly team members in this role must be based in Germany, Poland, or Ukraine, and they must be able to collaborate in person 2 weeks per quarter, traveling if necessary to the hub(s) where the team is based.*** The opportunity **Grammarly is the world’s leading AI writing assistance company trusted by over 30 million people and 70,000 professional teams every day. From instantly creating a first draft to perfecting every message, Grammarly’s product offerings help people at 96% of the Fortune 500 get their point across—and get results. Grammarly has been profitable for over a decade because we’ve stayed true to our values and built an enterprise-grade product that’s secure, reliable, and helps people do their best work—without selling their data. We’re proud to be one of Inc.’s best workplaces, a Glassdoor Best Place to Work, one of TIME’s 100 Most Influential Companies, and one of Fast Company’s Most Innovative Companies in AI.  
  
To achieve our ambitious goals, we’re looking for a Back-End Software Engineer to join our Cloud Product Platform team. This team owns critical back-end services that support all front-end applications. The team's technical health and engineering culture are vital to Grammarly’s long-term success.  
  
Grammarly’s engineers and researchers have the freedom to innovate and uncover breakthroughs—and, in turn, influence our product roadmap. The complexity of our technical challenges is growing rapidly as we scale our interfaces, algorithms, and infrastructure. Read more about our stack or hear from our team on our technical blog.  
  
**Your impact** As a Back-End Software Engineer on the Cloud Product Platform team, you will contribute to high-load, distributed API services.  
  
**In This Role, You Will**      
- Ensure the consistent availability and reliability of one of Grammarly's most heavily used services (3M active WS connections).
- Build back-end platform tools and interfaces, which are leveraged for all feature development in the company.
- Contribute to company-wide initiatives and collaborate with different teams.

**We’re Looking For Someone Who**
- Embodies our EAGER values—is ethical, adaptable, gritty, empathetic, and remarkable.
- Is inspired by our MOVE principles, which are the blueprint for how things get done at Grammarly: move fast and learn faster, obsess about creating customer value, value impact over activity, and embrace healthy disagreement rooted in trust.
- Is able to collaborate in person 2 weeks per quarter, traveling if necessary to the hub where the team is based.
- Has strong software engineering fundamentals, including knowledge of algorithms and data structures.
- Has solid experience in back-end development, ideally using Java or other JVM languages and multithreading.
- Has experience in building state-of-art back-end platforms.
- Has good knowledge of and some experience with AWS (or, alternatively, has deep expertise in Azure or GCE and is willing to learn AWS in a short time frame).
- Is excited about finding an optimal solution in situations of uncertainty.
- Enjoys fast-paced delivery and a consistent feedback loop.

**Support for you, professionally and personally**
- Professional growth: We believe that autonomy and trust are key to empowering our team members to do their best, most innovative work in a way that aligns with their interests, talents, and well-being. We also support professional development and advancement with training, coaching, and regular feedback.
- A connected team: Grammarly builds a product that helps people connect, and we apply this mindset to our own team. Our remote-first hybrid model enables a highly collaborative culture supported by our EAGER (ethical, adaptable, gritty, empathetic, and remarkable) values. We work to foster belonging among team members in a variety of ways. This includes our employee resource groups, Grammarly Circles, which promote connection among those with shared identities including BIPOC and LGBTQIA+ team members, women, and parents. We also celebrate our colleagues and accomplishments with global, local, and team-specific programs.
- Comprehensive benefits for candidates based in Germany or Ukraine: Grammarly offers all team members competitive pay along with a benefits package encompassing life care (including mental health care and risk benefits) and ample and defined time off. We also offer support to set up a home office, wellness and pet care stipends, learning and development opportunities, and more. Note that benefits may differ by location.

**We encourage you to apply** At Grammarly, we value our differences, and we encourage all to apply. Grammarly is an equal opportunity company. We do not discriminate on the basis of race or ethnic origin, religion or belief, gender, disability, sexual identity, or age.  
  
For more details about the personal data Grammarly collects during the recruitment process, for what purposes, and how you can address your rights, please see the Grammarly Data Privacy Notice for Candidates here.  
  
#DE  
  
*All team members meeting in person for official Grammarly business or working from a hub location are strongly encouraged to be vaccinated against COVID-19.*