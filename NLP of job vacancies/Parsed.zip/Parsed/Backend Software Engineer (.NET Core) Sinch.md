## 
              About the job

**About Us** Sinch is a global leader in cloud communications, helping businesses connect with their customers on their mobile phones. We reach every phone on earth, with over 147 billion conversations every year. Our technology powers the world's leading communications platforms.  
  
We are a dynamic and innovative team seeking a passionate backend software engineer to collaborate on our cloud-based communication solutions. Our applications, built using the latest versions of C# and .NET Core, are deployed as Docker and Kubernetes containers in AWS. If you are enthusiastic about crafting scalable and maintainable systems, thrive in a collaborative environment, and have a desire for staying ahead in the technology realm, we invite you to be part of our team in Stockholm. Remote colleagues from around the globe further enrich our diverse work culture.  
  
**Role Overview** **Role** As a Backend Software Engineer, you will play an essential role in developing robust distributed systems. You will have the opportunity to:  

- Influence design decisions.
- Actively participate in planning.
- Write high-quality code with a strong focus on testing.
- Launch innovative products and features.
- Monitor and maintain the entire system.

In our environment, teamwork is the key, and you will collaborate with talented engineers across teams, learning and growing together. At our core, we believe in personal responsibility and proactiveness.  
  
**Responsibilities**
- Create systems that are not only scalable but also resilient, ensuring graceful failure.
- Manage the software lifecycle from design and development to testing and production deployment.
- Work with a range of different technologies and programming languages, but primarily with C# and .NET Core.
- Actively contribute to enhancing our development processes and pipelines.
- Take a hands-on approach to monitoring production environments, identifying issues, and being on-call when necessary.
- Engage closely with software engineers, architects, DevOps specialists, and product managers to deliver exceptional products.

**Requirements**
- Minimum of 5 years in team-based development, deployment, and maintenance of software products in production.
- In-depth knowledge of .NET Core and a deep passion for technology.
- Strong written and verbal communication skills in English.
- Ability to function effectively within a cross-functional, self-organizing team.
- A passion for writing clean and testable code.
- Bachelor's degree in computer science or related technical discipline.

**Good to have**
- Experience working with service-oriented architecture and distributed systems.
- Experience with Docker and Kubernetes.
- Experience working with AWS.
- Experience with Asterisk and the SIP VoIP protocol.
- Proficiency in DevOps principles and practices.
- Background in shipping code in a CI/CD pipeline and actively seeking ways to optimize it.
- Proficient in working with a variety of databases, including relational databases such as MySQL and MSSQL, as well as NoSQL databases like MongoDB, Cassandra, and Redis

Embrace the challenge and join us!