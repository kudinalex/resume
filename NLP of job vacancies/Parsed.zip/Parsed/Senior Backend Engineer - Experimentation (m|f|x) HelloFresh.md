## 
              About the job

The role and the team  
  
We are a cross-functional team combining software engineering and data expertise. Our long term plan is to build a world-class platform for A/B testing at scale and foster a culture of experimentation in the company. As a data-driven company, we want experiments to drive every one of our business decisions. This role therefore has the potential for organization-wide impact. You will work with front and backend engineers, data engineers, and data scientists.  
  
Together, we’ll build and maintain an end-to-end solution for increasing the speed and power of experimentation at HelloFresh. Our tech stack includes big data processing pipelines, microservices for allocation management, third party tools for experiment configuration and statistical analysis, and SDK integrations for web, backend, and mobile platforms.  
  
What you’ll do  

- Raise the bar for experimentation in the company by serving as an ambassador for the proper implementation and evaluation of experiment designs.
- Take ownership of the architecture, design, development, deployment, and operations of the microservices you will build, using DevOps expertise, pair programming, and other best practice methodologies.
- Collaborate in an autonomous, cross-functional team with product owners, frontend engineers, data engineers, and business stakeholders.
- Develop an in-depth understanding of HelloFresh’s core product and architecture, and act as an ambassador for software solutions.
- Mentor and support colleagues, and share your knowledge across multiple experimentation teams and the rest of our tribe.

What you’ll bring  

- Industry experience building and working with experimentation platforms, event collection systems, and internal services for managing business metrics.
- Solid backend experience within microservice architectures using Golang.
- You embrace CI/CD methods and practices.
- Experience working with event-driven architectures using infrastructure like Kafka, RabbitMQ, etc.
- Experience working with relational databases, like PostgreSQL, and object stores, like AWS S3.
- You thrive when given the opportunity to collaborate and mentor team members, while also sharing practical knowledge and industry trends.
- Ability to deliver scalable, production-ready solutions in close collaboration with a product team.
- Ownership mindset, especially concerning operational objectives and customer focus.
- Demonstrable past experience with agile methodologies, with a strong focus on data-driven experimentation, lean thinking, and quick iterations

**Nice to have**
- Working with large scale data storage and processing technologies like Spark and Airflow.
- Experience working with Docker and container orchestration technologies such as Kubernetes.

Interacting with frontend developers, data engineers, product managers, and our teams around the world is very much part of our day-to-day, so communication skills are vital. We are looking for strong problem solvers who can apply their engineering skills to a wide range of platforms and environments, while also acting as role models and coaches for team members and stakeholders.  
  
Interacting with frontend developers, data engineers, product managers, and our teams around the world is very much part of our day-to-day, so communication skills are vital. We are looking for strong problem solvers who can apply their engineering skills to a wide range of platforms and environments, while also acting as role models and coaches for team members and stakeholders.  
  
#Decisions  
  
**12765**