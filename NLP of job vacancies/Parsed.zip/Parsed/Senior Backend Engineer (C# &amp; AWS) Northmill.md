## 
              About the job

We want to create a different kind of banking and shopping experience. Northmill was founded in 2006 and the main office is in Stockholm and Poland Engineering Center site is located in Katowice. Grab this opportunity to be a part of us and our journey!  
  
**The Scope Of Your Role**      
- As a Senior Backend Engineer, you will take part in the process of the design and development of modern financial applications.
- You will develop advanced monitoring systems used in running operations in the AWS cloud environments.
- You will have an impact on our applications by working closely with businesses and clients who use our banking products.
- You will work with C#, .NET, ASP.NET, AWS ( incl. fargate, lambda, S3, event bridge), Jira, Confluence, Git, and Rider/Visual Studio.
- You will use DDD and CQRS.

**Required Qualifications**
- 5+ years of commercial experience in creating web applications.
- Solid experience developing applications using C#.
- Solid experience in working with SQL databases.
- Willingness and interest to collaborate and work in a team.
- Stockholm as a place of living & SE citizenship or EES Resident status.

**Preferred Qualifications**
- Experience with software engineering best practices (code reviews, continuous integration, continuous deployment, testing).
- Exposure to Agile development methodologies.
- Familiar with Web services/web API.
- Familiar with the AWS platform.

**About you?** You are a creative and curious person with a genuine interest in software development. We are always looking for new knowledge and have a curiosity out of this world, we think that you have the same mindset and you are excited to read about the latest tech trends. You might also, like us, love to write nice and high-quality code.  
  
We hope you are not afraid to inform us about problems and have your thoughts on various solutions.  
  
You are a team player and used to work in an Agile environment.  
  
Since we are a multicultural team English is the required language.  
  
**We Offer**
- Work-life balance - hit the gym two minutes away or go for a jog in the city.
- Event - annual conference abroad and highly appreciated “Northchill” every month.
- Health - Gym membership as an optional benefit, monthly visits from a massage therapist at the office at an affordable cost.
- Breakfast and fruit every day, as well as holy “fika” each Friday.
- Regular after work and celebrated successes at the office.
- Stockholm’s most beautiful office 2020 with great spaces and views.

**About Northmill** A Swedish bank with the heart in the technique. 2.500 merchants. 600.000 end users.  
  
160 employees in four different countries, including Engineering Center hiring c.a. 40 experienced engineers. The goal? To improve financial life by being digital yet personal.  
  
**Apply today and be a part of Northmill!** Northmill is a tech company with a banking license aiming to improve financial life, offer merchants smart solutions and erase the borders between in-store and online.  
  
Northmill creates a more personal and relevant experience for people and companies, helping more than 2,500 merchants and 600,000 end users.  
  
**Saved for users **31 MSEK  
  
**Trustpilot **4.8 of 5  
  
**Cloud **100 %  
  
**End users **600 000