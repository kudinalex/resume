## 
              About the job

**Who We Are** A piece of the moon, a complete dinosaur skeleton, the Pope's hat, the world's smallest book - at Catawiki, we come across exceptional objects such as these every day.  
  
Catawiki is the leading online marketplace to buy and sell special objects. We offer over 75,000 special objects in auction every week — each reviewed and selected by one of Catawiki’s hundreds of in-house experts specialised in Art, Design, Jewellery, Fashion, Classic Cars, Collectables and many more.  
  
We've sold 10 million unique items to date and it’s our mission to become the world’s most popular auction destination for special objects.  
  
We’re an innovative, pioneering and** fast-growing scale-up**. If you think you can make a difference to our team, go ahead and apply.  
  
**How We Work** As the biggest marketplace for special items, Catawiki operates in a domain which brings plenty of unusual challenges and opportunities. You will be developing, testing and scaling our microservices, mostly written in Ruby, to handle the high volume of requests served by the platform every single day. We do this by using Infrastructure as Code principles, collaborative peer-reviews, Continuous Delivery, A/B testing every assumption and using the observability and monitoring tools already in place. We make mistakes and learn valuable lessons from them. Our focus is to be able to recover and iterate quickly.  
  
**What You’ll Do** Here at Catawiki, you will make an impact by improving and delivering product innovations for the Catawiki platform. Along with other members of the Development team, you will build scalable microservices while measuring and monitoring system performance. In addition, you will use experimentation, backed by data analysis, to add product features and deliver the best user experience on the platform.  
  
**What You’ll Bring** We look for engineers who are motivated to learn new things, ship new features, and pursue new and interesting challenges. Our stack is mainly focused around Ruby, however, if you’re passionate about learning new things then prior experience with Ruby is not essential. Next to this:  

- You have experience in designing, implementing and deploying backend services with a focus on high availability, low latency, and consistency.
- You have proven experience of collaborating closely with other engineers to become a valued member of an autonomous, cross-functional team.
- You have mentored junior engineers and you enjoy cooperating with engineers throughout the company.
- You understand the value that you can add to the business, the product and the impact of your work on customers.
- You feel comfortable documenting RFCS and describing problems, opportunities, pros and cons of solution alternatives.

As a passionate engineer, you bring these values to Catawiki:  

- You are a passionate experienced engineer with a strong eye for detail.
- You strive to be a great team player and don’t shy away from new challenges.
- You are comfortable in a startup environment and are ready to jump in and help if needed.
- You keep the company's values close to your heart and enjoy being in a diverse environment.

**Where you’ll be** This role is based in Amsterdam, The Netherlands. We also offer an excellent relocation package for people living outside of the Netherlands.  
  
**Here’s What We Can Offer You** This is your chance to join our mission to fulfil people’s passions, as part of a young and dynamic organisation. You'll be part of an enthusiastic, highly-motivated team of 800+ Catawikians. Additionally, you can expect:   

- A challenging role in a diverse, international and fast-growing organisation with over 50 nationalities.
- Regular fun activities both on and offline e.g summer parties, boat rides and regular team events.
- Great secondary benefits including a holiday allowance and a fantastic pension plan paid for by Catawiki.
- Hybrid ways of working between home and office. We offer remote and activity-based working, suited to the team and individual responsibilities
- We care about our teams’ wellbeing and offer a holistic wellbeing programme including our Employee Assistance Programme offering clinical services, single-session therapy, wellness support and more.
- Tailored learning and development opportunities to support your personal and professional growth;
- We want to help you celebrate special occasions in life by:
    - providing employees with a 100 EURO Catavoucher upon joining and 50 EURO birthday Catavouchers;
    - Extra days of annual leave for work anniversaries at 3, 5, 8 and 10 years;
    - Additional leave allowances for important life events such as moving, engagement & marriage;
    - Each year Catawikians get an additional day’s leave to Pursue their Passion!

Please note that our benefits offering changes depending on which country you are employed in. For our country-specific offering please ask your recruiter.  
  
**Our commitment to you **Catawiki’s eclectic team represents an international and intergenerational mix of people from different professional and cultural backgrounds. We foster an inclusive and queer-friendly work environment, committed to making every Catawikian feel welcomed and empowered. Whatever your story, we encourage you to bring your unique perspective to the table.  
  
Catawiki stands with Ukraine and encourages people displaced by the current conflict to apply. In addition to the several initiatives we’ve launched, we’re open to ideas on ways we can continue to support the humanitarian effort.  
  
**Our offices and way of working** We have sensational offices in Amsterdam, Groningen, Paris and our newest office in Lisbon. Most of our employees are within commutable distance of one of our office locations and enjoy a hybrid work model. This means we expect you to be in the office 2 out of 5 days, roughly 40% of your working time, to collaborate and connect with each other. The exception is of course, if the job description specifically states that the role is 100% remote, as some experts and sales positions are.  
  
**Interested?** Apply directly with an English CV and cover letter by submitting your information at the bottom of this page. By submitting your application you agree to Catawiki’s Applicant Privacy Policy.  
  
*If you’re excited about this role but your past experience doesn’t align perfectly with every qualification in the job description, we encourage you to apply anyways. You may be just the right candidate for this or other roles.*