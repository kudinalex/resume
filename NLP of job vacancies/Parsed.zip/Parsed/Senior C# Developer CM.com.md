## 
              About the job

**We connect @CM.com**

CM.com is a fast growing, listed, and global tech company. We offer over 40 software products to our customers, which you’ve probably already touched by receiving text or WhatsApp messages, buying tickets for festivals or while chatting via an AI chatbot for your support questions. We help create the ultimate customer experience for our customers to you, the end user.

All techy stuff, but we believe in people that make the difference. And that is exactly what our bright bunch of ambitious caring colleagues do. Every day. Together. Entrepreneurial people are the beating heart of our club. And this way, we can take on any challenge that comes our way. Our credo has been the same since the beginning in 1999 : “Do what you like, do what you’re good at, and contribute.”

AND we are transparent, humble, and approachable regardless of age, culture, background, gender or religion e.g. Everyone is allowed backstage and allowed on the VIP deck, together.

**What you will do**

You will work together with 6 Software Engineers at the Financial & Data payments team located in Breda, focusing on Payment Service Provider.

You are expected to work on projects related to portal development, payouts, balancing services, and reconciliation.

As a Senior C# Developer with a passion for cutting-edge technologies and a strong background in Angular, RabbitMQ, containerization, and Kubernetes, you are to collaborate with cross-functional teams to design, develop, and maintain scalable software solutions.

**You connect with us, if you:**
      
- Have a bachelor's or master's degree in computer science or similar.
- You have +5 proven experience in Back-End using .netCore and C#.
- Proficiency in Angular for front-end development.
- Strong background in RabbitMQ for messaging solutions.
- Experience with containerization (Docker) and Kubernetes for deployment.
- Solid understanding of software development principles and best practices.
- Excellent communication skills in English and Dutch will be a nice to have.
- Located from travel distance from our office in Breda.

**Benefits of working @CM.com**

In our Global Onboarding program, we want you and all our other new Club Members to have a complete deep dive into the culture of CM.com. An exciting program will be waiting for you! To keep you connected with your colleagues we organize great events in our headquarters in Breda filled with informative, practical, and fun activities. Furthermore, we come together as a club during the Friday afternoon drinks, and our Healthy Free office breakfast and lunch.

- Your salary is a given, and we offer a pension plan of 8% of your monthly salary, 25 holidays, holiday allowance and if you need to travel, we got you covered.
- You have the possibility to participate in our Employee Share Purchase Program and get a discount on purchasing shares.
- And if you want to develop yourself professionally, we offer internal and/or external training courses like Udemy and the CM Academy. To promote internal knowledge sharing we organize different types of Meetups with external speakers.

**Ready to join the Club? Apply now!**

Yes! Apply via the company website and the assigned Recruiter will be in touch. Ready to join the club?

AND we are transparent, humble, and approachable regardless of age, culture, background, gender or religion e.g. Everyone is allowed backstage and allowed on the VIP deck, together.