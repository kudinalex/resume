## 
              About the job

**Company Description** Our goal is a solar power system on every roof, a storage unit in every house, and an e-car in every garage. How are we achieving this? Enpal makes solar easy: we rent out solar power systems, electricity storage and wallboxes at an all-inclusive rate, supplemented by a low-cost green electricity tariff, and intelligently networked into an integrated overall solution.  
  
We are just at the beginning of our journey to becoming Europe's largest energy company. That's why we're looking for talented people to accompany us on this journey, leave their footprint and celebrate successes together with us. At Enpal, you will find a dynamic working environment as well as the space to develop yourself personally and professionally and to use your strengths effectively.  
  
As the first green unicorn in Germany and the fastest-growing energy company in Europe (FT1000 Ranking 2022 by Financial Times & Statista), we continue to advance our mission of green energy for everyone. Be part of this success story and change the world with us!  
  
**Job Description** As a **Senior Software Engineer C# (f/m/d)** you will work on complex problems in delivering renewable energy solutions: from digitalizing the planning of installation of solar panels with compelling frontend applications, to building APIs supporting real time energy data, all the way to scaling and operating cloud infrastructure in Azure.  
  
We offer speed, agility, and steep career growth. Our vision to make sustainable solar energy available to everyone can only come to live through our customer and product oriented view, and the cooperation between software development, product management and lean, experiment-driven business development.  
  
Join us to develop your professional skills, take part in the energy revolution, and let us take ownership of the sustainable change we want to see in the world together! We are looking forward to your application.  
  
At Enpal, you would be  

- building software. We are serious about delivering incremental value in each iteration, and we celebrate when we improve people's experience with our solution, make an impact towards our climate goals.
- improving developer happiness. Nobody wants to stay up until midnight to deploy new solutions, or run the same regression tests manually day in, day out. We're about improving stability, automating as much as we can including load tests and vulnerability scans.
- growing & learning. Do you know all there is to know about Kafka or are you experienced on graceful degradation? We’d love to learn from your knowledge. Feel like you're behind on test-driven development in React, is Azure Bicep new to you? We’ll make sure you grow through our knowledge.
- working on architecture & vision. We are fusing old and new technologies; cloud-native microservices, IoT applications, a Salesforce backbone, an event-driven architecture. This means we analyze new requirements critically to see which moving parts would have to change, explore opportunities to solve organization-spanning challenges with elegant architectural solutions.
- steering for empathy and understanding. Only when we comprehend what the market needs we can create solutions that truly address underlying challenges. Ask critical questions and listen to operations, craftspeople, sales - there are so many stakeholders and users to get input from, and balancing their needs leads to the best solutions.

**Qualifications** We are looking for roughly a 50% fit with for what we ask. The other 50% is a surprise to us, it is the magic you bring to the table and the diversity in which you make us grow.  

- you have good experience in software development
- you are experienced in C# and ideally React.
- your experience with Azure, MongoDB, Flutter, SalesForce, DevOps is a plus.
- you communicate clearly in English, spoken and written. Crisp and concise ways of formulating your ideas and opinions. Knowledge of German is a plus. '
- you are inspired by the energy transition and want to make a difference. We are one of the biggest players in the solar business and want to make this change with you.
- you want to participate in a company where empowerment and initiative is valued. We are looking for people who want to grow their personal skills and knowledge, take responsibility, steer and influence for what they feel is right.
- agile and lean values are embodied by you. People over processes. Code over documentation. Reducing waste by building minimum viable products first, testing it with real users, growing and maintaining solutions as requirements evolve.

**Additional Information**
- Work in Germany's first green unicorn and actively shape the solar energy revolution.
- The sun shines all over the world - at Enpal you will find a highly motivated and diverse team with more than 65 different nationalities.
- Would you rather keep your pet company at home or your colleagues at the office? Even after the pandemic, we offer you a hybrid working model
- We fulfill every start-up cliché - in our modern office in Berlin-Friedrichshain, you'll find everything your heart desires, from a ping-pong table and yoga corner to a roof terrace and stocked drinks fridges.
- Your kick-start at Enpal - Get to know the company, your team colleagues and our founder Mario on your onboarding day.
- Stay up to date - Whether it's company figures at our monthly all-hands meetings or how a photovoltaic system works at the Lunch & Learn, you'll always know exactly what's going on.
- Energy transition only works together - At Enpal, you can expect a legendary team spirit and unforgettable team events.
- No mistakes, no progress - We live a strong feedback culture and grow with your input, either personally or anonymously via our feedback tool Culture Amp.

*At Enpal, we are proud of the diversity of our team. No decisions are made on the basis of skin colour, religion or religious belief, ethnic or national origin, nationality, gender identity, sexual orientation, disability or age, either during recruitment or employment. Enpal stands for a safe workplace and takes action against discrimination and harassment of any kind.*