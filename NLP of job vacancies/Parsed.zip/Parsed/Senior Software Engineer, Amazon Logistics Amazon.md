## 
              About the job

**Description** If you want to join a fast-paced, innovative team that is making history and breaking new ground for Amazon, this is the place for you.  
  
Who are we?  
  
It’s no secret that Amazon relies on its technology to deliver millions of packages every day to its customers – on time, with low cost. We, the Last Mile Delivery Technology organization, build the complex software solutions that work across our vendors, warehouses and carriers to optimize both the time and cost of getting packages delivered. Our products and services already handle thousands of requests per second, make business decisions impacting billions of dollars a year, integrate with a network of small and large carriers worldwide, manage business rules for millions of unique products, and improve the ordering and delivery experience for millions of online shoppers.  
  
We are looking for Senior Software Development Engineer in Luxembourg with expertise in full stack web development to be part of our AMZL supply chain team. The successful candidate will be a self-starter comfortable with ambiguity, with strong attention to detail, and enjoys working with large scale of data.  
  
**Key Responsibilities, But Not Limited To, Would Be**      
- Work with product management and cross functional teams to help develop requirements for products and UX.
- Develop the overall design & architecture (including UX) of the software and data solutions
- Establish standards for coding, review process, design and delivery of the software solutions.
- Provide mentorship to other engineers, contribute code to a new product feature, review designs and code.
- Assist in estimation of efforts required for feature development for sprint planning.
- Engage with Amazon Web Services team to continuously learn about their new product offerings and assess usage of those for software development.
- Help create new product ideas with prototypes and white papers.
- Advise senior and executive management using your technical expertise.

We are open to hiring candidates to work out of one of the following locations:  
  
London, GBR  
  
**Basic Qualifications**
- Experience as a mentor, tech lead or leading an engineering team
- Experience leading the architecture and design (architecture, design patterns, reliability and scaling) of new and current systems
- Experience in professional, non-internship software development
- Experience programming with at least one modern language such as Java, C++, or C# including object-oriented design
- Experience in development in the last 3 years

**Preferred Qualifications**
- Bachelor's degree in computer science or equivalent
- Experience with full software development life cycle, including coding standards, code reviews, source control management, build processes, testing, and operations

Amazon is an equal opportunities employer. We believe passionately that employing a diverse workforce is central to our success. We make recruiting decisions based on your experience and skills. We value your passion to discover, invent, simplify and build. Protecting your privacy and the security of your data is a longstanding top priority for Amazon. Please consult our Privacy Notice (https://www.amazon.jobs/en/privacy\_page) to know more about how we collect, use and transfer the personal data of our candidates.  
  
Our inclusive culture empowers Amazonians to deliver the best results for our customers. If you have a disability and need an adjustment during the application and hiring process, including support for the interview or onboarding process, please contact the Applicant-Candidate Accommodation Team (ACAT), Monday through Friday from 7:00 am GMT - 4:00 pm GMT. If calling directly from the United Kingdom, please dial +44 800 086 9884 (tel:+448000869884). If calling from Ireland, please dial +353 1800 851 489 (tel:+3531800851489).  

**Company** - Amazon UK Services Ltd. - A10  
  
Job ID: A2531537