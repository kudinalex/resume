## 
              About the job

Do you want to be in an environment that will enable you to impact billions of lives through your work? Do you want to be part of a culture that celebrates diversity and out-of-the-box thinking?  
  
At Microsoft our mission is to empower every person and every organisation on the planet to achieve more. As a software engineer at Microsoft, you will be encouraged to come forward with ideas and continue to foster collaborative environments that empower our colleagues to showcase their brilliance.  
  
**Microsoft have multiple positions open for Software Engineers across all different levels to be hired in our Serbian Development Centre, to work on some of the best known (and best unknown) technologies in the world!** Some of the hiring teams are (but not limited to):  
  
Azure Data, a Microsoft team that drives the future of data processing in the Microsoft Cloud. Our software development team, located in Belgrade, is building some of the most advanced and widely used data processing cloud services in the world. The services we build are based on groundbreaking technology and are global market leaders, with millions of active users, and applications ranging from small shops to large mission critical business workloads. Each service provides the benefits of automated database management: patching, backups, high-availability, security, and many more. We're hiring for multiple services and teams within Azure Data.  
  
Azure SQL Database and Azure SQL Managed Instance are database services based on Microsoft SQL Server technology, and are surface area compatible with the most popular proprietary DB tech in the world. Benefits of instant scaling and serverless mode, as well as intelligent performance tuning and security are available to all applications, whether migrated on-premise workloads or apps natively built for the cloud.  
  
Azure Database for PostgreSQL is a database service based on PostgreSQL technology, the most popular open-source DB tech in the world. Applications can enjoy the richness of PostgreSQL surface area developed by the ecosystem, such as JSONB, geospatial support, rich indexing and dozens of extensions, while also enjoying the benefits of a fully-managed cloud service: fast scaling, intelligent performance tuning, and automated security.  
  
Microsoft Fabric - Synapse Datawarehouse is a data-lake centric data warehouse built on an enterprise grade distributed processing engine that enables industry leading performance at scale while eliminating the user burden of configuration and management. The warehouse is tightly coupled with Power BI, as well as complementary technologies such as Spark, data streaming, and AI analytics tools.  
  
We are looking for Software Engineers **at all levels** who are passionate and highly motivated to work on researching, solving deep technical problems, taking on challenges, and delivering cutting-edge market-leading software. In this role you will collaborate with some of the world's leading experts in this area of technology, and have an excellent opportunity to learn, grow and advance your career.  
  
**Responsibilities**      
- Design, produce and deliver software to improve the reliability, scalability, performance, security, and efficiency of a cloud service.
- Contribute with fixing, enhancing, and supporting our services in production, including periodic on-call duties.
- Collaborate with colleagues across the world to address all requirements needed to run enterprise-grade services.
- Participate actively in code reviews, bug/issue triage with the feature teams, and support well informed decisions towards business and engineering goals.
- Review and influence ongoing design, architecture, standards and methods for operating services and systems.
- Drive and lead the software development projects from technical perspective.
- Proactively come up with the proposals for further improvements of the system, process and owned product.
- Mentor and guide the junior engineering colleagues.

**Qualifications**
- Degree in computer science, electrical engineering, software engineering, or a related technical discipline
- Experience in the software engineering industry.
- Passion and motivation for technology.
- Understanding of software engineering principles.
- Ability to effectively communicate in English.
- Passion for growth, exploring new things, and learning from others and own mistakes.
- Experience in one or more programming languages, including, but not limited to: C/C++, Java, C#, Python, JS, TypeScript, PowerShell, Rust
- Experience with planning, organizing, and executing improvements on components and feature areas.
- Drive for customer engagement and obsession, with data driven approach.
- Formal and non-formal leadership skills.

**We have roles at varying levels of seniority, so happy to consider whatever stage you are at currently.** Microsoft is an equal opportunity employer. Consistent with applicable law, all qualified applicants will receive consideration for employment without regard to age, ancestry, citizenship, color, family or medical care leave, gender identity or expression, genetic information, immigration status, marital status, medical condition, national origin, physical or mental disability, political affiliation, protected veteran or military status, race, ethnicity, religion, sex (including pregnancy), sexual orientation, or any other characteristic protected by applicable local laws, regulations and ordinances. If you need assistance and/or a reasonable accommodation due to a disability during the application process, read more about requesting accommodations.